import { NgModule } from '@angular/core';
import { environment } from './environment';
import { ENVIRONMENT } from 'web-components-lib';

@NgModule({
  providers: [
    {
      provide: ENVIRONMENT,
      useValue: environment,
    },
  ],
})
export class EnvironmentModule {}
