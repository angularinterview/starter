export interface Environment {
  production: boolean;
  apiBaseUrl: string;
}
