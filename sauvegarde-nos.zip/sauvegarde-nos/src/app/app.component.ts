import { Component } from '@angular/core';

@Component({
  selector: 'alz-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  title = 'allianz-starter';
}
