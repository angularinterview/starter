const fs = require('fs-extra');
const concat = require('concat');

(async function build() {
  const files = [
    './dist/soins-web-component/runtime.js',
    './dist/soins-web-component/polyfills-es5.js',
    './dist/soins-web-component/main.js',
  ]

  await concat(files, './dist/soins-web-component/soins-web-component.js');
  await fs.copyFile('./dist/soins-web-component/soins-web-component.js', '../TS_2AVNOSClient/src/main/webapp/skins/agent/js/soins-web-component.js');
  await fs.copyFile('./dist/soins-web-component/styles.css', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/styles.css');
  // FIXME: fonts are not loaded as expected from fonts directory
  await fs.copyFile('./dist/soins-web-component/fontawesome-webfont.eot', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fontawesome-webfont.eot');
  await fs.copyFile('./dist/soins-web-component/fontawesome-webfont.ttf', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fontawesome-webfont.ttf');
  await fs.copyFile('./dist/soins-web-component/fontawesome-webfont.woff', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fontawesome-webfont.woff');
})()



