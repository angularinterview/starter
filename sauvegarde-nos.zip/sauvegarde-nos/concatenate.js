const fs = require('fs-extra');
const concat = require('concat');

(async function build() {
  const files = [
    './dist/soins-web-component/runtime.js',
    './dist/soins-web-component/polyfills-es5.js',
    './dist/soins-web-component/main.js',
  ]

  await concat(files, './dist/soins-web-component/soins-web-component.js');
  await fs.copyFile('./dist/soins-web-component/soins-web-component.js', '../TS_2AVNOSClient/src/main/webapp/skins/agent/js/soins-web-component.js');
  await fs.copyFile('./dist/soins-web-component/styles.css', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/styles.css');

  await fs.copyFile('./dist/soins-web-component/fa-regular-400.eot', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fa-regular-400.eot');
  await fs.copyFile('./dist/soins-web-component/fa-regular-400.svg', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fa-regular-400.svg');
  await fs.copyFile('./dist/soins-web-component/fa-regular-400.ttf', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fa-regular-400.ttf');
  await fs.copyFile('./dist/soins-web-component/fa-regular-400.woff', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fa-regular-400.woff');
  await fs.copyFile('./dist/soins-web-component/fa-regular-400.woff2', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fa-regular-400.woff2');
  await fs.copyFile('./dist/soins-web-component/fa-solid-900.eot', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fa-solid-900.eot');
  await fs.copyFile('./dist/soins-web-component/fa-solid-900.svg', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fa-solid-900.svg');
  await fs.copyFile('./dist/soins-web-component/fa-solid-900.ttf', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fa-solid-900.ttf');
  await fs.copyFile('./dist/soins-web-component/fa-solid-900.woff', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fa-solid-900.woff');
  await fs.copyFile('./dist/soins-web-component/fa-solid-900.woff2', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/fa-solid-900.woff2');

  await fs.copyFile('./dist/soins-web-component/3rdpartylicenses.txt', '../TS_2AVNOSClient/src/main/webapp/skins/agent/css/3rdpartylicenses.txt');
})()



