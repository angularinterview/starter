import { Converter } from '../../core/converters/converter';
import { GarantiesSante, NiveauGarantieEnum } from '../garanties-sante/_model/garanties-sante.model';
import { ProduitGarantieHospiBean, SoinAssureBean } from '../assure-selector/_model/assure.model';
import { NIVEAU_SOINS_GAMME_BEAN_MAP } from '../assure-selector/_model/assure.constants';

export type PARTIAL_FIELDS =
  | 'niveauHospiSoinsCourants'
  | 'niveauOptiqueAuditif'
  | 'niveauDentaire'
  | 'renfortHospi'
  | 'renfortMedecinesDouces'
  | 'renfortOptique'
  | 'renfortDentaire'
  | 'forfaitHospit'
  | 'produitGarantieHospiBean'
  | 'gammeBean';

export class GarantiesSanteToSoinAssureConveter extends Converter<
  GarantiesSante,
  Pick<SoinAssureBean, PARTIAL_FIELDS>
> {
  convert(garantiesSante: GarantiesSante): Pick<SoinAssureBean, PARTIAL_FIELDS> {
    return {
      niveauHospiSoinsCourants: garantiesSante.niveau,
      niveauOptiqueAuditif: this.computeNiveau(garantiesSante.niveau, garantiesSante.renfort.optique),
      niveauDentaire: this.computeNiveau(garantiesSante.niveau, garantiesSante.renfort.dentaire),
      renfortMedecinesDouces: 'N',
      renfortHospi: garantiesSante.renfort.serenite ? 'O' : 'N',
      renfortOptique: garantiesSante.renfort.optique ? 'O' : 'N',
      renfortDentaire: garantiesSante.renfort.dentaire ? 'O' : 'N',
      forfaitHospit: garantiesSante.forfaitHospitalier ? 'O' : 'N',
      produitGarantieHospiBean: {
        codeProduit: garantiesSante.garantieHospitaliere.codeGarantieHospitaliere,
        montantGarantie: garantiesSante.garantieHospitaliere.montant,
      } as ProduitGarantieHospiBean,
      gammeBean: NIVEAU_SOINS_GAMME_BEAN_MAP.get(garantiesSante.niveau)!,
    };
  }

  private computeNiveau(niveau: NiveauGarantieEnum, renfort: boolean): number {
    let toReturn = niveau;
    if (renfort) {
      switch (niveau) {
        case NiveauGarantieEnum.NIVEAU_1:
        case NiveauGarantieEnum.NIVEAU_2:
        case NiveauGarantieEnum.NIVEAU_3:
          toReturn = NiveauGarantieEnum.NIVEAU_4;
          break;
        case NiveauGarantieEnum.NIVEAU_5:
        case NiveauGarantieEnum.NIVEAU_7:
          toReturn = NiveauGarantieEnum.NIVEAU_6;
          break;
      }
    }
    return toReturn;
  }
}
