import { Converter } from '../../core/converters/converter';
import { GarantiesSante } from '../garanties-sante/_model/garanties-sante.model';
import { SoinAssureBean } from '../assure-selector/_model/assure.model';

export class SoinAssureToGarantiesSanteConveter extends Converter<SoinAssureBean, GarantiesSante> {
  convert(soinAssure: SoinAssureBean): GarantiesSante {
    return {
      niveau: soinAssure.niveauHospiSoinsCourants,
      renfort: {
        serenite: soinAssure.renfortHospi === 'O',
        optique: soinAssure.renfortOptique === 'O',
        dentaire: soinAssure.renfortDentaire === 'O',
      },
      forfaitHospitalier: soinAssure.forfaitHospit === 'O',
      garantieHospitaliere: {
        codeGarantieHospitaliere: soinAssure.produitGarantieHospiBean?.codeProduit || null,
        montant: soinAssure.produitGarantieHospiBean?.montantGarantie,
      },
    };
  }
}
