import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { GarantiesSante } from './garanties-sante/_model/garanties-sante.model';
import { NosBeanFacade } from '../core/store/nos-bean/nos-bean.facade';
import { AssuresFacade } from '../core/store/assures/assures.facade';
import { IdPersonneNOS } from './_model/soins.model';
import { first } from 'rxjs/operators';
import { SoinAssureToGarantiesSanteConveter } from './converters/soin-assure-to-garanties-sante.conveter';
import { Assure } from './assure-selector/_model/assure.model';

@Component({
  selector: 'lib-onglet-soins',
  templateUrl: './onglet-soins.component.html',
  styleUrls: ['./onglet-soins.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OngletSoinsComponent implements OnInit {
  @Input() ongletSoinsForm: FormGroup = new FormGroup({});

  indexAssureSelectionne = 0;

  @Input() checkFormValidity(checkFormValidity: boolean): boolean {
    // console.log('checkFormValidity function called !');
    // console.log('ongletSoinsForm.valid', this.ongletSoinsForm.valid);
    return checkFormValidity && this.ongletSoinsForm.valid;
  }

  constructor(
    private formBuilder: FormBuilder,
    private nosBeanFacade: NosBeanFacade,
    public assuresFacade: AssuresFacade
  ) {}

  ngOnInit(): void {
    this.nosBeanFacade.loadNosBean();

    this.assuresFacade.assures$.pipe(first()).subscribe((assures) => {
      this.ongletSoinsForm = this.formBuilder.group({
        garantiesSanteAssures: this.formBuilder.array(
          assures.map((assure) =>
            this.formBuilder.group({
              idPersonneNOS: assure.idPersonneNOS,
              garantiesSante: this.formBuilder.control(
                new SoinAssureToGarantiesSanteConveter().convert(assure.soinAssureBean)
              ),
            })
          )
        ),
      });
    });

    this.assuresFacade.assures$.subscribe((assures) => {
      (this.ongletSoinsForm.get('garantiesSanteAssures') as FormArray).patchValue(
        assures.map((assure) => ({
          idPersonneNOS: assure.idPersonneNOS,
          garantiesSante: new SoinAssureToGarantiesSanteConveter().convert(assure.soinAssureBean),
        }))
      );
    });
  }

  onIndexAssureSelectionneChanged(indexAssureSelectionne: number) {
    this.indexAssureSelectionne = indexAssureSelectionne;
  }

  onCalculerTarifRequest(idPersonneNOS: IdPersonneNOS) {
    this.assuresFacade.calculerTarif(idPersonneNOS);
  }

  onGarantiesSanteChanged(idPersonneNOS: IdPersonneNOS, garantiesSante: GarantiesSante) {
    this.assuresFacade.updateGarantiesSanteAssure(idPersonneNOS, garantiesSante);
  }

  onAppliquerATousRequest(idPersonneNOS: IdPersonneNOS) {
    this.assuresFacade.appliquerATous(idPersonneNOS);
  }

  trackById(index: number, item: Assure) {
    return item.idPersonneNOS;
  }

  displayForm() {
    console.log(this.ongletSoinsForm.value);
  }
}
