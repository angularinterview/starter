import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { GarantiesSante } from './garanties-sante/_model/garanties-sante.model';
import { NosBeanFacade } from '../core/store/nos-bean/nos-bean.facade';
import { AssuresFacade } from '../core/store/assures/assures.facade';
import { IdPersonneNOS } from './_model/soins.model';
import { first, takeUntil } from 'rxjs/operators';
import { Assure, SelectedAssure } from './assure-selector/_model/assure.model';
import { NgbCarousel } from '@ng-bootstrap/ng-bootstrap';
import { Subject } from 'rxjs';

@Component({
  selector: 'lib-onglet-soins',
  templateUrl: './onglet-soins.component.html',
  styleUrls: ['./onglet-soins.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OngletSoinsComponent implements OnInit, OnDestroy {
  @ViewChild(NgbCarousel, { static: false }) carousel: NgbCarousel;
  private ngUnsubscribe = new Subject();
  selectedAssure = new Subject<SelectedAssure>();

  @Input() ongletSoinsForm: FormGroup = new FormGroup({});

  @Input() alimenterFormOngletSoins = (callback: () => never) => {
    this.nosBeanFacade.alimenterFormOngletSoins(callback);
  };

  @Input() alimenterCodesProduit = (callback: () => never) => {
    this.nosBeanFacade.alimenterCodesProduit(callback);
  };

  @Output() ouvrirPDFRequest = new EventEmitter<string>();

  constructor(
    private formBuilder: FormBuilder,
    private nosBeanFacade: NosBeanFacade,
    public assuresFacade: AssuresFacade
  ) {}

  ngOnInit(): void {
    this.nosBeanFacade.loadNosBean();

    this.selectedAssure
      .asObservable()
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe(({ idPersonneNOS, index }) => {
        this.carousel.select(idPersonneNOS);
        this.assuresFacade.initCouverture(idPersonneNOS);
      });

    this.assuresFacade.assures$.pipe(first()).subscribe((assures) => {
      this.ongletSoinsForm = this.formBuilder.group({
        garantiesSanteAssures: this.formBuilder.array(
          assures.map((assure) =>
            this.formBuilder.group({
              idPersonneNOS: assure.idPersonneNOS,
              garantiesSante: [null, Validators.required],
            })
          )
        ),
      });
    });
  }

  onSelectedAssureChanged(selectedAssure: SelectedAssure) {
    this.selectedAssure.next(selectedAssure);
  }

  onCalculerTarifRequest(idPersonneNOS: IdPersonneNOS) {
    this.assuresFacade.calculerTarif(idPersonneNOS);
  }

  onGarantiesSanteChanged(idPersonneNOS: IdPersonneNOS, garantiesSante: GarantiesSante) {
    this.assuresFacade.updateGarantiesSanteAssure(idPersonneNOS, garantiesSante);
  }

  onAppliquerATousRequest(idPersonneNOS: IdPersonneNOS) {
    this.assuresFacade.appliquerATous(idPersonneNOS);
  }

  onInitCouvertureRequest(idPersonneNOS: IdPersonneNOS) {
    this.assuresFacade.initCouverture(idPersonneNOS);
  }

  trackById(index: number, item: Assure) {
    return item.idPersonneNOS;
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
