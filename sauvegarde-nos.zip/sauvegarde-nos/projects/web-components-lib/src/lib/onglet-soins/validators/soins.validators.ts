import { AbstractControl, ValidatorFn } from '@angular/forms';

export class SoinsValidators {
  static cotisation: ValidatorFn = (control: AbstractControl) => {
    const value = parseFloat(control.value);
    return !isNaN(value) && value > 0 ? null : { cotisationInvalid: value };
  };

  static garantiesHospitalieres: ValidatorFn = (fg: AbstractControl) => {
    const codeGarantieHospitaliere = fg.get('codeGarantieHospitaliere')?.value;
    const montant = parseFloat(fg.get('montant')?.value);
    const isValid =
      (Boolean(codeGarantieHospitaliere) && !isNaN(montant) && montant >= 15 && montant <= 80) ||
      (!Boolean(codeGarantieHospitaliere) && !Boolean(montant));

    if (!isValid) {
      fg.get('montant')?.setErrors({ error: true });
    }

    return isValid
      ? null
      : {
          valid: false,
          message: `Le montant de souscription (${codeGarantieHospitaliere}) doit être compris entre 15 € et 80 € inclus`,
        };
  };
}
