export * from './onglet-soins.component';
export * from './onglet-soins.module';
