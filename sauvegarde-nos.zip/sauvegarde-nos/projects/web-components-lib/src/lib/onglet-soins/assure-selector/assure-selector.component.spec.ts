import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssureSelectorComponent } from './assure-selector.component';

describe('AssureSelectorComponent', () => {
  let component: AssureSelectorComponent;
  let fixture: ComponentFixture<AssureSelectorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AssureSelectorComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssureSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
