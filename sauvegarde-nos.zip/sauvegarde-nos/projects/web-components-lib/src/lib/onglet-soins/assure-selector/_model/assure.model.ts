import { GammeBean, IdPersonneNOS } from '../../_model/soins.model';
import { NiveauGarantieEnum } from '../../garanties-sante/_model/garanties-sante.model';

export enum CodeGarantieHospitaliereEnum {
  OSGH2 = 'OSGH2',
  OSGH4 = 'OSGH4',
}

export type Assures = Array<Assure>;

export interface Assure {
  idPersonneNOS: IdPersonneNOS;
  idPr?: any;
  idRattachementPersonneNOS?: any;
  categorieSociale: string;
  categorieSocialeMenu: string;
  categorieSocialeSousMenu?: any;
  dateDebutActivite: string;
  isEnActivite: string;
  dateNaissance: string;
  age: string;
  nom: string;
  prenom: string;
  qualite: string;
  sexe?: any;
  profil: string;
  libelleProfil: string;
  rattachementOuCSP: string;
  codePostal: string;
  commune: string;
  complementNumeroRue: string;
  numeroRue: string;
  typeVoie: string;
  voie: string;
  numeroSS: string;
  regimeObligatoire?: any;
  codeProfessionLagon: string;
  mapAttributRO: MapAttributRO;
  isAssurePrincipal: boolean;
  affichageGarantiesBean: AffichageGarantiesBean;
  soinAssureBean: SoinAssureBean;
  besoinAssureBean: BesoinAssureBean;
  clauseBeanList?: any;
  assurePrincipal: boolean;
  sexeSouscription: string;
  prenomNom: string;
  dateNaissancePourMN: string;
  dateDebutActiviteMN: string;
  categorieSocialeTarif: string;
  regimeObligatoireIms: string;
  categorieSocialeIms: string;
}

export interface BesoinAssureBean {
  niveauHospiSoinsCourants: number;
  niveauOptiqueAuditif: number;
  niveauDentaire: number;
  renfortHospi?: any;
  renfortMedecinesDouces?: any;
  gammeBean?: any;
  forfaitHospit?: any;
}

export interface SoinAssureBean {
  tarifMensuelOffreBudget: number;
  tarifChoixClient: number;
  tarifChoixClientAnnuel: number;
  produitHospiBean: ProduitHospiBean;
  produitGarantieHospiBean: ProduitGarantieHospiBean;
  produitGarantieForfaitHospiBean: ProduitGarantieForfaitHospiBean;
  forfaitHospitaliasationBean?: any;
  niveauHospiSoinsCourants: NiveauGarantieEnum;
  niveauxGarantiesAutorises: Array<NiveauGarantieEnum>;
  niveauOptiqueAuditif: number;
  niveauDentaire: number;
  renfortHospi: string;
  renfortMedecinesDouces: string;
  produitNOSBean: ProduitHospiBean;
  renfortOptique: string;
  renfortDentaire: string;
  abrogationBean?: any;
  gammeBean: GammeBean;
  forfaitHospit: string;
  forfaitHospiSelected: string;
  tauxAMC?: any;
  topGHSeuleSelected?: any;
  repriseDevisGH: boolean;
  hospiSeule: boolean;
}

export interface ProduitGarantieForfaitHospiBean {
  codeProduit: string;
  libelleProduit?: any;
  montantCotisationTTCAnnuel: number;
  montantCotisationTTCFractionne: string;
  montantCotisationHorsPrimesTTCAnnuel: string;
  montantCotisationPrimesTTCAnnuel: string;
  codeAssistance?: any;
  codeGarantie: number;
  codeGarantieAssistance: number;
  typeProduit?: any;
  montantGarantieForfaitHospi: number;
}

export interface ProduitGarantieHospiBean {
  codeProduit: CodeGarantieHospitaliereEnum;
  libelleProduit: string;
  montantCotisationTTCAnnuel: string;
  montantCotisationTTCFractionne: string;
  montantCotisationHorsPrimesTTCAnnuel: string;
  montantCotisationPrimesTTCAnnuel: string;
  codeAssistance?: any;
  codeGarantie: number;
  codeGarantieAssistance: number;
  typeProduit?: any;
  montantGarantie: number;
}

export interface ProduitHospiBean {
  codeProduit: string;
  libelleProduit?: any;
  montantCotisationTTCAnnuel: string;
  montantCotisationTTCFractionne: string;
  montantCotisationHorsPrimesTTCAnnuel: string;
  montantCotisationPrimesTTCAnnuel: string;
  codeAssistance: string;
  codeGarantie: number;
  codeGarantieAssistance: number;
  typeProduit?: any;
}

export interface AffichageGarantiesBean {
  axeGarantieBeanList: AxeGarantieBeanList[];
  libelleHospitalisationSeule: string;
  niveauAutoriseBeanList: NiveauAutoriseBeanList[];
  garantieHospitaliereBeanList: GarantieHospitaliereBeanList[];
  renfortGarantieBeanList: RenfortGarantieBeanList[];
  forfaitHospitaliasationBean: ForfaitHospitaliasationBean;
}

export interface ForfaitHospitaliasationBean {
  libelleFofaitHospi: string;
  idForfaitHospi: string;
  codeProduit?: any;
  repriseDevis: boolean;
}

export interface RenfortGarantieBeanList {
  libelleRenfortGarantie: string;
  detailRenfortGarantieBeanList: DetailRenfortGarantieBeanList[];
  topRenfort?: boolean;
  idRenfortGarantie: string;
  isTopRenfort?: boolean;
}

export interface DetailRenfortGarantieBeanList {
  detailRenfortGarantie: string;
}

export interface GarantieHospitaliereBeanList {
  codeGarantieHospitaliere: string;
  libelleGarantieHospitaliere: string;
}

export interface NiveauAutoriseBeanList {
  codeNiveau: string;
  libelleNiveau: string;
}

export interface AxeGarantieBeanList {
  libelleDetailGarantieBeanList: LibelleDetailGarantieBeanList[];
  detailGarantieBeanList: DetailGarantieBeanList[];
  niveauRemboursementSelect?: any;
  libelleAxeGarantie: string;
  idAxeGarantie: string;
}

export interface DetailGarantieBeanList {
  niveauRemboursementDetailAxeGarantieBeanList: NiveauRemboursementDetailAxeGarantieBeanList[];
  codeNiveauRemboursement: string;
}

export interface NiveauRemboursementDetailAxeGarantieBeanList {
  niveauRemboursement: string;
}

export interface LibelleDetailGarantieBeanList {
  libelleDetailGarantie: string;
}

export interface MapAttributRO {
  commune: string;
  voie: string;
  numeroRue: string;
  dateNaissance: string;
  codePostal: string;
  prenom: string;
  qualite: string;
  nom: string;
  numeroSS: string;
  typeVoie: string;
}
