import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssureSelectorComponent } from './assure-selector.component';

@NgModule({
  declarations: [AssureSelectorComponent],
  exports: [AssureSelectorComponent],
  imports: [CommonModule],
})
export class AssureSelectorModule {}
