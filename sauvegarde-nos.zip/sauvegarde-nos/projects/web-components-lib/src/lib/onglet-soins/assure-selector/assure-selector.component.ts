import { AfterViewInit, ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Assure, Assures, SelectedAssure } from './_model/assure.model';

@Component({
  selector: 'lib-assure-selector',
  templateUrl: './assure-selector.component.html',
  styleUrls: ['./assure-selector.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AssureSelectorComponent implements AfterViewInit {
  private _assures: Assures;
  indexAssureSelectionne = 0;

  @Input() set assures(assures: Assures) {
    this._assures = assures;
  }

  get assures() {
    return this._assures || [];
  }

  @Output() selectedAssureChanged = new EventEmitter<SelectedAssure>();

  constructor() {}

  ngAfterViewInit(): void {
    if (this.assures.length) {
      this.indexAssureSelectionne = 0;
      this.selectedAssureChanged.emit({
        idPersonneNOS: this.assures[this.indexAssureSelectionne].idPersonneNOS,
        index: this.indexAssureSelectionne,
      });
    }
  }

  get assureSelectionne(): Assure | undefined {
    return this.assures.length ? this.assures[this.indexAssureSelectionne] : undefined;
  }

  get buttonSuivantEnabled() {
    return (
      this.assures.length > this.indexAssureSelectionne + 1 &&
      this.assureSelectionne &&
      this.assureSelectionne.soinAssureBean.tarifChoixClient > 0
    );
  }

  get buttonPrecedentEnabled() {
    return this.indexAssureSelectionne > 0;
  }

  goToAssureSuivant() {
    this.indexAssureSelectionne = Math.min(this.indexAssureSelectionne + 1, this.assures.length - 1);
    this.selectedAssureChanged.emit({
      idPersonneNOS: this.assures[this.indexAssureSelectionne].idPersonneNOS,
      index: this.indexAssureSelectionne,
    });
  }

  goToAssurePrecedent() {
    this.indexAssureSelectionne = Math.max(this.indexAssureSelectionne - 1, 0);
    this.selectedAssureChanged.emit({
      idPersonneNOS: this.assures[this.indexAssureSelectionne].idPersonneNOS,
      index: this.indexAssureSelectionne,
    });
  }
}
