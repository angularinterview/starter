import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Assure, Assures } from './_model/assure.model';

@Component({
  selector: 'lib-assure-selector',
  templateUrl: './assure-selector.component.html',
  styleUrls: ['./assure-selector.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AssureSelectorComponent implements OnInit {
  indexAssureSelectionne: number = 0;
  private _assures: Assures;

  @Input() set assures(assures: Assures) {
    this._assures = assures;
  }

  get assures() {
    return this._assures || [];
  }

  @Output() indexAssureSelectionneChanged = new EventEmitter<number>();

  constructor() {}

  ngOnInit(): void {
    // if (this.assures.length) {
    //   this.indexAssureSelectionne = 0;
    //   this.indexAssureSelectionneChanged.emit(this.indexAssureSelectionne);
    // }
  }

  get assureSelectionne(): Assure | undefined {
    return this.assures.length ? this.assures[this.indexAssureSelectionne] : undefined;
  }

  get buttonSuivantEnabled() {
    return (
      this.assures.length > this.indexAssureSelectionne + 1 &&
      this.assureSelectionne &&
      this.assureSelectionne.soinAssureBean.tarifChoixClient > 0
    );
  }

  get buttonPrecedentEnabled() {
    return this.indexAssureSelectionne > 0;
  }

  goToAssureSuivant() {
    this.indexAssureSelectionne = Math.min(this.indexAssureSelectionne + 1, this.assures.length - 1);
    this.indexAssureSelectionneChanged.emit(this.indexAssureSelectionne);
  }

  goToAssurePrecedent() {
    this.indexAssureSelectionne = Math.max(this.indexAssureSelectionne - 1, 0);
    this.indexAssureSelectionneChanged.emit(this.indexAssureSelectionne);
  }
}
