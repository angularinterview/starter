import { GammeBean } from '../../_model/soins.model';
import { NiveauGarantieEnum } from '../../garanties-sante/_model/garanties-sante.model';

export const GAMME_HOSPI: GammeBean = { idGamme: 'I', libelleGamme: 'Hospi' };
export const GAMME_BUDGET: GammeBean = { idGamme: 'O', libelleGamme: 'Budget' };
export const GAMME_CLASSIC: GammeBean = { idGamme: 'T', libelleGamme: 'Classic' };
export const GAMME_PLUS: GammeBean = { idGamme: 'M', libelleGamme: 'Plus' };

export const NIVEAU_SOINS_GAMME_BEAN_MAP: Map<NiveauGarantieEnum, GammeBean> = new Map([
  [NiveauGarantieEnum.HOSPI, GAMME_HOSPI],
  [NiveauGarantieEnum.ECO, GAMME_BUDGET],
  [NiveauGarantieEnum.NIVEAU_1, GAMME_CLASSIC],
  [NiveauGarantieEnum.NIVEAU_2, GAMME_CLASSIC],
  [NiveauGarantieEnum.NIVEAU_3, GAMME_CLASSIC],
  [NiveauGarantieEnum.NIVEAU_4, GAMME_CLASSIC],
  [NiveauGarantieEnum.NIVEAU_5, GAMME_PLUS],
  [NiveauGarantieEnum.NIVEAU_6, GAMME_PLUS],
  [NiveauGarantieEnum.NIVEAU_7, GAMME_PLUS],
]);
