import { GammeBean } from '../../_model/soins.model';
import { NiveauSoinsEnum } from '../../garanties-sante/_model/garanties-sante.model';

const GAMME_HOSPI: GammeBean = { idGamme: 'I', libelleGamme: 'Hospi' };
const GAMME_BUDGET: GammeBean = { idGamme: 'O', libelleGamme: 'Budget' };
const GAMME_CLASSIC: GammeBean = { idGamme: 'T', libelleGamme: 'Classic' };
const GAMME_PLUS: GammeBean = { idGamme: 'M', libelleGamme: 'Plus' };

export const NIVEAU_SOINS_GAMME_BEAN_MAP: Map<NiveauSoinsEnum, GammeBean> = new Map([
  [NiveauSoinsEnum.HOSPI, GAMME_HOSPI],
  [NiveauSoinsEnum.ECO, GAMME_BUDGET],
  [NiveauSoinsEnum.NIVEAU_1, GAMME_CLASSIC],
  [NiveauSoinsEnum.NIVEAU_2, GAMME_CLASSIC],
  [NiveauSoinsEnum.NIVEAU_3, GAMME_CLASSIC],
  [NiveauSoinsEnum.NIVEAU_4, GAMME_CLASSIC],
  [NiveauSoinsEnum.NIVEAU_5, GAMME_PLUS],
  [NiveauSoinsEnum.NIVEAU_6, GAMME_PLUS],
  [NiveauSoinsEnum.NIVEAU_7, GAMME_PLUS],
]);
