import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OptionsRenfortComponent } from './options-renfort.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [OptionsRenfortComponent],
  imports: [CommonModule, ReactiveFormsModule],
  exports: [OptionsRenfortComponent],
})
export class OptionsRenfortModule {}
