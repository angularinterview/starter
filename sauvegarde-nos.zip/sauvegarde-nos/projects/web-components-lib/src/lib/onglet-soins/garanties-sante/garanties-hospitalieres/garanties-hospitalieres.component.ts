import { Component, Input } from '@angular/core';
import { BaseControlValueAccessor } from '../../../core/forms/base-control-value-accessor';
import { AbstractControl, FormBuilder, FormGroup } from '@angular/forms';
import { controlValueAccessorProvidersFactory } from '../../../core/forms/form.helpers';
import { CodeGarantieHospitaliereEnum } from '../../assure-selector/_model/assure.model';
import { SoinsValidators } from '../../validators/soins.validators';

const garantiesHospitalieresFormInitialValue = {
  codeGarantieHospitaliere: null,
  montant: null,
};

@Component({
  selector: 'lib-garanties-hospitalieres',
  templateUrl: './garanties-hospitalieres.component.html',
  styleUrls: ['./garanties-hospitalieres.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [...controlValueAccessorProvidersFactory(GarantiesHospitalieresComponent)],
})
export class GarantiesHospitalieresComponent extends BaseControlValueAccessor {
  readonly CodeGarantieHospitaliereEnum = CodeGarantieHospitaliereEnum;
  readonly garantiesHospitalieresForm: FormGroup;

  @Input() index: number;

  constructor(private formBuilder: FormBuilder) {
    super();
    this.garantiesHospitalieresForm = formBuilder.group(garantiesHospitalieresFormInitialValue, {
      validators: SoinsValidators.garantiesHospitalieres,
    });
    this.garantiesHospitalieresForm.get('codeGarantieHospitaliere')?.valueChanges.subscribe(() => {
      this.garantiesHospitalieresForm.patchValue(
        {
          montant: null,
        },
        { emitEvent: false }
      );
    });
  }

  getForm(): AbstractControl {
    return this.garantiesHospitalieresForm;
  }

  onGarantieHospitaliereClick(codeGarantieHospitaliere: CodeGarantieHospitaliereEnum, event: Event) {
    if (codeGarantieHospitaliere === this.garantiesHospitalieresForm.get('codeGarantieHospitaliere')?.value) {
      this.garantiesHospitalieresForm.setValue(garantiesHospitalieresFormInitialValue);
    }
  }

  amountFieldShouldBeEnabled(codeGarantieHospitaliere: CodeGarantieHospitaliereEnum): boolean {
    return this.garantiesHospitalieresForm.get('codeGarantieHospitaliere')?.value === codeGarantieHospitaliere;
  }
}
