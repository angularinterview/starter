import { Component, Input, OnDestroy } from '@angular/core';
import { BaseControlValueAccessor } from '../../../core/forms/base-control-value-accessor';
import { AbstractControl, FormBuilder, FormGroup } from '@angular/forms';
import { controlValueAccessorProvidersFactory } from '../../../core/forms/form.helpers';
import { CodeGarantieHospitaliereEnum } from '../../assure-selector/_model/assure.model';
import { SoinsValidators } from '../../validators/soins.validators';
import { merge, Subject } from 'rxjs';
import { map, takeUntil } from 'rxjs/operators';

const garantiesHospitalieresFormInitialValue = {
  codeGarantieHospitaliere: null,
  montant: null,
  checkboxOSGH2: false,
  checkboxOSGH4: false,
};

interface CheckboxEvent {
  selected: boolean;
  source: CodeGarantieHospitaliereEnum;
}

@Component({
  selector: 'lib-garanties-hospitalieres',
  templateUrl: './garanties-hospitalieres.component.html',
  styleUrls: ['./garanties-hospitalieres.component.scss'],
  // changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [...controlValueAccessorProvidersFactory(GarantiesHospitalieresComponent)],
})
export class GarantiesHospitalieresComponent extends BaseControlValueAccessor implements OnDestroy {
  private ngUnsubscribe = new Subject();
  readonly CodeGarantieHospitaliereEnum = CodeGarantieHospitaliereEnum;
  readonly garantiesHospitalieresForm: FormGroup;

  @Input() index: number;

  @Input() set formDisabled(disabled: boolean) {
    this.setDisabledState(disabled);
  }

  constructor(private formBuilder: FormBuilder) {
    super();
    this.garantiesHospitalieresForm = formBuilder.group(garantiesHospitalieresFormInitialValue, {
      validators: SoinsValidators.garantiesHospitalieres,
    });

    merge(
      this.garantiesHospitalieresForm.get('checkboxOSGH2')!.valueChanges.pipe(
        map<boolean, CheckboxEvent>((selected) => ({
          selected,
          source: CodeGarantieHospitaliereEnum.OSGH2,
        }))
      ),
      this.garantiesHospitalieresForm.get('checkboxOSGH4')!.valueChanges.pipe(
        map<boolean, CheckboxEvent>((selected) => ({
          selected,
          source: CodeGarantieHospitaliereEnum.OSGH4,
        }))
      )
    )
      .pipe(takeUntil(this.ngUnsubscribe))
      .subscribe((checkboxEvent) => {
        this.garantiesHospitalieresForm.patchValue(
          {
            codeGarantieHospitaliere: checkboxEvent.selected ? checkboxEvent.source : null,
            checkboxOSGH2: checkboxEvent.selected && checkboxEvent.source === CodeGarantieHospitaliereEnum.OSGH2,
            checkboxOSGH4: checkboxEvent.selected && checkboxEvent.source === CodeGarantieHospitaliereEnum.OSGH4,
            montant: null,
          },
          { emitEvent: false }
        );
      });
  }

  getForm(): AbstractControl {
    return this.garantiesHospitalieresForm;
  }

  amountFieldEnabled(codeGarantieHospitaliere: CodeGarantieHospitaliereEnum): boolean {
    return this.garantiesHospitalieresForm.get('codeGarantieHospitaliere')?.value === codeGarantieHospitaliere;
  }

  ngOnDestroy(): void {
    this.ngUnsubscribe.next();
    this.ngUnsubscribe.complete();
  }
}
