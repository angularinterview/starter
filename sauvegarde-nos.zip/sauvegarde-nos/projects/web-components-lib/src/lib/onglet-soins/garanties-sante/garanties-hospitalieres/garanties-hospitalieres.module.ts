import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GarantiesHospitalieresComponent } from './garanties-hospitalieres.component';
import { ReactiveFormsModule } from '@angular/forms';
import { IMaskModule } from 'angular-imask';
import { TooltipModule } from 'ng2-tooltip-directive';

@NgModule({
  declarations: [GarantiesHospitalieresComponent],
  exports: [GarantiesHospitalieresComponent],
  imports: [CommonModule, ReactiveFormsModule, IMaskModule, TooltipModule],
})
export class GarantiesHospitalieresModule {}
