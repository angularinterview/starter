import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnInit,
  Output,
  QueryList,
  ViewChildren,
} from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup } from '@angular/forms';
import { GarantiesSante, GarantiesSanteForm, NiveauSoinsEnum } from './_model/garanties-sante.model';
import { BaseControlValueAccessor } from '../../core/forms/base-control-value-accessor';
import { controlValueAccessorProvidersFactory } from '../../core/forms/form.helpers';
import { debounceTime } from 'rxjs/operators';
import { Assure } from '../assure-selector/_model/assure.model';

@Component({
  selector: 'lib-garanties-sante',
  templateUrl: './garanties-sante.component.html',
  styleUrls: ['garanties-sante.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [...controlValueAccessorProvidersFactory(GarantiesSanteComponent)],
})
export class GarantiesSanteComponent extends BaseControlValueAccessor implements AfterViewInit, OnInit {
  @ViewChildren('radio') radios: QueryList<ElementRef>;
  readonly NiveauSoinsEnum = NiveauSoinsEnum;
  readonly garantiesSanteForm: FormGroup;

  @Input() niveauxNonSelectionnesDesactives: boolean;

  @Input() index: number;

  @Input() assure: Assure;

  @Input() tousNiveauxDesactives: boolean;

  @Output() calculerTarifRequest = new EventEmitter<void>();

  @Output() garantiesSanteChanged = new EventEmitter<GarantiesSante>();

  @Output() appliquerATousRequest = new EventEmitter<void>();

  constructor(private formBuilder: FormBuilder, private changeDetectorRef: ChangeDetectorRef) {
    super();
    this.garantiesSanteForm = this.formBuilder.group(new GarantiesSanteForm());
  }

  getForm(): AbstractControl {
    return this.garantiesSanteForm;
  }

  ngOnInit(): void {
    this.garantiesSanteForm.get('niveau')?.valueChanges.subscribe(() => {
      (this.garantiesSanteForm.get('renfort') as FormGroup).patchValue(
        {
          serenite: false,
          optique: false,
          dentaire: false,
        },
        {
          emitEvent: false,
        }
      );
    });
  }

  ngAfterViewInit(): void {
    super.ngAfterViewInit();
    if (this.niveauxNonSelectionnesDesactives) {
      this.radios.forEach((item) => {
        if (item.nativeElement.id !== this.garantiesSanteForm.get('niveau')?.value) {
          item.nativeElement.disabled = true;
        }
      });
      this.changeDetectorRef.detectChanges();
    }

    if (this.tousNiveauxDesactives) {
      this.radios.forEach((item) => {
        item.nativeElement.disabled = true;
      });
      this.changeDetectorRef.detectChanges();
    }

    this.garantiesSanteForm.valueChanges.pipe(debounceTime(100)).subscribe((garantiesSante) => {
      this.garantiesSanteChanged.emit(garantiesSante);
    });
  }

  calculerTarifEnabled(): boolean {
    return this.garantiesSanteForm.valid && !Boolean(this.assure.soinAssureBean.tarifChoixClient);
  }

  calculerTarif(): void {
    this.calculerTarifRequest.emit();
  }

  appliquerATous(): void {
    this.appliquerATousRequest.emit();
  }

  appendIndex(id: number): string {
    return `${id}-${this.index}`;
  }
}
