import { AfterViewInit, ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup } from '@angular/forms';
import { GarantiesSante, GarantiesSanteForm, NiveauGarantieEnum } from './_model/garanties-sante.model';
import { BaseControlValueAccessor } from '../../core/forms/base-control-value-accessor';
import { controlValueAccessorProvidersFactory } from '../../core/forms/form.helpers';
import { Assure } from '../assure-selector/_model/assure.model';
import { GAMME_HOSPI } from '../assure-selector/_model/assure.constants';
import { debounceTime } from 'rxjs/operators';
import { SoinAssureToGarantiesSanteConveter } from '../converters/soin-assure-to-garanties-sante.conveter';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalContentComponent } from '../../core/modal/modal-content.component';

@Component({
  selector: 'lib-garanties-sante',
  templateUrl: './garanties-sante.component.html',
  styleUrls: ['garanties-sante.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [...controlValueAccessorProvidersFactory(GarantiesSanteComponent)],
})
export class GarantiesSanteComponent extends BaseControlValueAccessor implements AfterViewInit, OnInit {
  readonly NiveauGarantieEnum = NiveauGarantieEnum;
  readonly GAMME_HOSPI = GAMME_HOSPI;
  readonly garantiesSanteForm: FormGroup;

  @Input() niveauxNonSelectionnesDesactives: boolean;

  @Input() index: number;

  private _assure: Assure;

  @Input() set assure(assure: Assure) {
    this._assure = assure;
    this.garantiesSanteForm.patchValue(new SoinAssureToGarantiesSanteConveter().convert(assure.soinAssureBean), {
      emitEvent: false,
    });
  }

  get assure(): Assure {
    return this._assure;
  }

  @Output() calculerTarifRequest = new EventEmitter<void>();

  @Output() garantiesSanteChanged = new EventEmitter<GarantiesSante>();

  @Output() appliquerATousRequest = new EventEmitter<void>();

  @Output() initCouvertureRequest = new EventEmitter<void>();

  @Output() ouvrirPDFRequest = new EventEmitter<string>();

  constructor(private formBuilder: FormBuilder, private modalService: NgbModal) {
    super();
    this.garantiesSanteForm = this.formBuilder.group(new GarantiesSanteForm());
  }

  getForm(): AbstractControl {
    return this.garantiesSanteForm;
  }

  ngOnInit(): void {
    this.garantiesSanteForm.get('niveau')?.valueChanges.subscribe(() => {
      (this.garantiesSanteForm.get('renfort') as FormGroup).patchValue(
        {
          serenite: false,
          optique: false,
          dentaire: false,
        },
        {
          emitEvent: false,
        }
      );
    });
  }

  ngAfterViewInit(): void {
    super.ngAfterViewInit();

    this.garantiesSanteForm.valueChanges.pipe(debounceTime(100)).subscribe((garantiesSante) => {
      this.garantiesSanteChanged.emit(garantiesSante);
    });
  }

  calculerTarifEnabled(): boolean {
    return this.garantiesSanteForm.valid && !Boolean(this.assure.soinAssureBean.tarifChoixClient);
  }

  niveauEnabled(niveau: NiveauGarantieEnum): boolean {
    return this.assure.soinAssureBean.niveauxGarantiesAutorises.includes(niveau);
  }

  calculerTarif(): void {
    this.calculerTarifRequest.emit();
  }

  appliquerATous(): void {
    if (!this.assure.isAssurePrincipal) {
      const modalRef = this.modalService.open(ModalContentComponent);
      modalRef.componentInstance.config = {
        header: 'Appliquer à tous',
        message: 'Attention, cette action va écraser le choix des clients précédents. Merci de confirmer votre choix.',
        buttons: [
          {
            label: 'No',
            classes: ['btn-outline-dark'],
            action: () => {
              modalRef.close(false);
            },
          },
          {
            label: 'Yes',
            classes: ['btn-outline-success'],
            action: () => {
              modalRef.close(true);
            },
          },
        ],
      };

      modalRef.result.then((response) => {
        if (response) {
          this.appliquerATousRequest.emit();
        }
      });
    } else {
      this.appliquerATousRequest.emit();
    }
  }

  appendIndex(id: number): string {
    return `${id}-${this.index}`;
  }
}
