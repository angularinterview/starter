import { FormControl } from '@angular/forms';

export enum TypeRenfortEnum {
  SERENITE = 'SERENITE',
  OPTIQUE = 'OPTIQUE',
  DENTAIRE = 'DENTAIRE',
}

export class OptionsRenfortForm {
  serenite = new FormControl(false);
  optique = new FormControl(false);
  dentaire = new FormControl(false);
}

export class OptionsRenfort {
  serenite: boolean;
  optique: boolean;
  dentaire: boolean;
}
