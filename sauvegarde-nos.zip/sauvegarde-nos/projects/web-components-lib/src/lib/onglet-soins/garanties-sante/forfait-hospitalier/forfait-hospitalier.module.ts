import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ForfaitHospitalierComponent } from './forfait-hospitalier.component';
import { ReactiveFormsModule } from '@angular/forms';
import { TooltipModule } from 'ng2-tooltip-directive';

@NgModule({
  declarations: [ForfaitHospitalierComponent],
  exports: [ForfaitHospitalierComponent],
  imports: [CommonModule, ReactiveFormsModule, TooltipModule],
})
export class ForfaitHospitalierModule {}
