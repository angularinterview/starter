import { FormControl, Validators } from '@angular/forms';
import { OptionsRenfort } from '../options-renfort/_model/options-renfort.model';
import { CodeGarantieHospitaliereEnum, SoinAssureBean } from '../../assure-selector/_model/assure.model';
import { SoinAssureToGarantiesSanteConveter } from '../../converters/soin-assure-to-garanties-sante.conveter';

export enum NiveauSoinsEnum {
  HOSPI = -1,
  ECO,
  NIVEAU_1,
  NIVEAU_2,
  NIVEAU_3,
  NIVEAU_4,
  NIVEAU_5,
  NIVEAU_6,
  NIVEAU_7,
}

export class GarantiesSanteForm {
  niveau = new FormControl(null, [
    Validators.required,
    Validators.min(NiveauSoinsEnum.HOSPI),
    Validators.max(NiveauSoinsEnum.NIVEAU_7),
  ]);
  renfort = new FormControl();
  forfaitHospitalier = new FormControl();
  garantieHospitaliere = new FormControl();

  constructor(soinAssureBean?: SoinAssureBean) {
    if (soinAssureBean) {
      const garantiesSante = new SoinAssureToGarantiesSanteConveter().convert(soinAssureBean);
      this.niveau.setValue(garantiesSante.niveau);
      this.renfort.setValue(garantiesSante.renfort);
    }
  }
}

export interface GarantiesSante {
  niveau: NiveauSoinsEnum;
  renfort: OptionsRenfort;
  forfaitHospitalier: boolean;
  garantieHospitaliere: {
    codeGarantieHospitaliere: CodeGarantieHospitaliereEnum;
    montant: number;
  };
}
