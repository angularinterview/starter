import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { GarantiesSanteComponent } from './garanties-sante.component';
import { ReactiveFormsModule } from '@angular/forms';
import { OptionsRenfortModule } from './options-renfort/options-renfort.module';
import { GarantiesHospitalieresModule } from './garanties-hospitalieres/garanties-hospitalieres.module';
import { ForfaitHospitalierModule } from './forfait-hospitalier/forfait-hospitalier.module';
import { TooltipModule } from 'ng2-tooltip-directive';
import { ModalContentModule } from '../../core/modal/modal-content.module';

@NgModule({
  declarations: [GarantiesSanteComponent],
  exports: [GarantiesSanteComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    ModalContentModule,
    TooltipModule,
    OptionsRenfortModule,
    ForfaitHospitalierModule,
    GarantiesHospitalieresModule,
  ],
})
export class GarantiesSanteModule {}
