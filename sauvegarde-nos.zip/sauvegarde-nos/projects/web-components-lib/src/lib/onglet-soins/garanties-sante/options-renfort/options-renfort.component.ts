import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseControlValueAccessor } from '../../../core/forms/base-control-value-accessor';
import { AbstractControl, FormBuilder, FormGroup } from '@angular/forms';
import { NiveauGarantieEnum } from '../_model/garanties-sante.model';
import { OptionsRenfort, OptionsRenfortForm, TypeRenfortEnum } from './_model/options-renfort.model';
import { controlValueAccessorProvidersFactory } from '../../../core/forms/form.helpers';

@Component({
  selector: 'lib-options-renfort',
  templateUrl: './options-renfort.component.html',
  styleUrls: ['./options-renfort.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [...controlValueAccessorProvidersFactory(OptionsRenfortComponent)],
})
export class OptionsRenfortComponent extends BaseControlValueAccessor {
  readonly TypeRenfortEnum = TypeRenfortEnum;
  readonly renfortsForm: FormGroup;

  @Input() index: number;

  @Input() niveau: NiveauGarantieEnum;

  @Input() niveauEnabled: boolean;

  @Input() hideSerenite = false;

  @Input() hideOptique = false;

  @Input() hideDentaire = false;

  @Input() niveauSelectionne: NiveauGarantieEnum;

  constructor(private formBuilder: FormBuilder) {
    super();
    this.renfortsForm = this.formBuilder.group(new OptionsRenfortForm());
  }

  enabled(): boolean {
    return Boolean(this.niveau) && this.niveauEnabled && this.niveauSelectionne === this.niveau;
  }

  isOptionChecked(option: keyof OptionsRenfort): boolean {
    return this.renfortsForm.get(option)?.value && this.niveau === this.niveauSelectionne;
  }

  getForm(): AbstractControl {
    return this.renfortsForm;
  }
}
