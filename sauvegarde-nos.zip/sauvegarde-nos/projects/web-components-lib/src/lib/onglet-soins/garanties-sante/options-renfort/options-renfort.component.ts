import { Component, forwardRef, Input } from '@angular/core';
import { BaseControlValueAccessor } from '../../../core/forms/base-control-value-accessor';
import { AbstractControl, FormBuilder, FormGroup, NG_VALIDATORS, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NiveauSoinsEnum } from '../_model/garanties-sante.model';
import { OptionsRenfortForm, TypeRenfortEnum } from './_model/options-renfort.model';
import { controlValueAccessorProvidersFactory } from '../../../core/forms/form.helpers';

@Component({
  selector: 'lib-options-renfort',
  templateUrl: './options-renfort.component.html',
  styleUrls: ['./options-renfort.component.scss'],
  providers: [...controlValueAccessorProvidersFactory(OptionsRenfortComponent)],
})
export class OptionsRenfortComponent extends BaseControlValueAccessor {
  readonly TypeRenfortEnum = TypeRenfortEnum;
  readonly renfortsForm: FormGroup;
  enabled = false;

  @Input() niveau: NiveauSoinsEnum;

  @Input() hideSerenite = false;

  @Input() hideOptique = false;

  @Input() hideDentaire = false;

  @Input()
  set niveauSelectionne(niveauSelectionne: NiveauSoinsEnum) {
    this.enabled = Boolean(this.niveau) && niveauSelectionne === this.niveau;
  }

  constructor(private formBuilder: FormBuilder) {
    super();
    this.renfortsForm = this.formBuilder.group(new OptionsRenfortForm());
  }

  getForm(): AbstractControl {
    return this.renfortsForm;
  }

  writeValue(val: any) {
    if (this.enabled) {
      super.writeValue(val);
    }
  }

  enableChangesPropagation(): boolean {
    return this.enabled;
  }
}
