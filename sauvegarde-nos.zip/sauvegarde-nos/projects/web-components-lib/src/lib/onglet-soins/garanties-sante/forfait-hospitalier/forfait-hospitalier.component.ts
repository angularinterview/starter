import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseControlValueAccessor } from '../../../core/forms/base-control-value-accessor';
import { AbstractControl, FormControl } from '@angular/forms';
import { controlValueAccessorProvidersFactory } from '../../../core/forms/form.helpers';

@Component({
  selector: 'lib-forfait-hospitalier',
  templateUrl: './forfait-hospitalier.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [...controlValueAccessorProvidersFactory(ForfaitHospitalierComponent)],
})
export class ForfaitHospitalierComponent extends BaseControlValueAccessor {
  readonly forfaitHospitalierForm = new FormControl(false);

  @Input() index: number;

  getForm(): AbstractControl {
    return this.forfaitHospitalierForm;
  }
}
