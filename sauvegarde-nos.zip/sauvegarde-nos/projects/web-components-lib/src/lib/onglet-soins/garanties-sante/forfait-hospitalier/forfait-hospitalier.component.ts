import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { BaseControlValueAccessor } from '../../../core/forms/base-control-value-accessor';
import { AbstractControl, FormControl } from '@angular/forms';
import { controlValueAccessorProvidersFactory } from '../../../core/forms/form.helpers';

@Component({
  selector: 'lib-forfait-hospitalier',
  templateUrl: './forfait-hospitalier.component.html',
  styleUrls: ['./forfait-hospitalier.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [...controlValueAccessorProvidersFactory(ForfaitHospitalierComponent)],
})
export class ForfaitHospitalierComponent extends BaseControlValueAccessor {
  readonly forfaitHospitalierForm = new FormControl(false);
  private _formDisabled: boolean;

  @Input() index: number;

  @Input() set formDisabled(disabled: boolean) {
    this._formDisabled = disabled;
    if (disabled) {
      this.forfaitHospitalierForm.disable({ emitEvent: false });
    } else {
      this.forfaitHospitalierForm.enable({ emitEvent: false });
    }
  }

  get formDisabled(): boolean {
    return this._formDisabled;
  }

  @Output() forfaitHospitalierChanged = new EventEmitter<void>();

  constructor() {
    super();
    this.forfaitHospitalierForm.valueChanges.subscribe(() => this.forfaitHospitalierChanged.emit());
  }

  getForm(): AbstractControl {
    return this.forfaitHospitalierForm;
  }
}
