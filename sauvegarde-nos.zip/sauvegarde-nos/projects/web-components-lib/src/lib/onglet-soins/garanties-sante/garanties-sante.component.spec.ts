import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GarantiesSanteComponent } from './garanties-sante.component';

describe('SoinsComponent', () => {
  let component: GarantiesSanteComponent;
  let fixture: ComponentFixture<GarantiesSanteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GarantiesSanteComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GarantiesSanteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
