import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GarantiesSanteComponent } from './garanties-sante.component';
import { GarantiesSanteModule } from './garanties-sante.module';
import { nosBeanMock } from '../../../../../../mock-data/db';

describe('GarantiesSanteComponent', () => {
  let component: GarantiesSanteComponent;
  let fixture: ComponentFixture<GarantiesSanteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GarantiesSanteModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GarantiesSanteComponent);
    component = fixture.componentInstance;
    component.assure = nosBeanMock.assureBeanList[0];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
