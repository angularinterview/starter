import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OptionsRenfortComponent } from './options-renfort.component';
import { OptionsRenfortModule } from './options-renfort.module';

describe('RenfortsComponent', () => {
  let component: OptionsRenfortComponent;
  let fixture: ComponentFixture<OptionsRenfortComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OptionsRenfortModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OptionsRenfortComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
