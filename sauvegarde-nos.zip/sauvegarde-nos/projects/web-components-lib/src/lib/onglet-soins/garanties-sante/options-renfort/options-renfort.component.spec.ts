import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OptionsRenfortComponent } from './options-renfort.component';

describe('RenfortsComponent', () => {
  let component: OptionsRenfortComponent;
  let fixture: ComponentFixture<OptionsRenfortComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [OptionsRenfortComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OptionsRenfortComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
