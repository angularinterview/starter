import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ForfaitHospitalierComponent } from './forfait-hospitalier.component';
import { ForfaitHospitalierModule } from './forfait-hospitalier.module';

describe('ForfaitHospitalierComponent', () => {
  let component: ForfaitHospitalierComponent;
  let fixture: ComponentFixture<ForfaitHospitalierComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ForfaitHospitalierModule],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ForfaitHospitalierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
