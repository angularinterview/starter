import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GarantiesHospitalieresComponent } from './garanties-hospitalieres.component';

describe('GarantiesHospitalieresComponent', () => {
  let component: GarantiesHospitalieresComponent;
  let fixture: ComponentFixture<GarantiesHospitalieresComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GarantiesHospitalieresComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GarantiesHospitalieresComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
