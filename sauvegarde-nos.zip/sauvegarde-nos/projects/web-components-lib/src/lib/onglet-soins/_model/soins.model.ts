import { Assure, Assures } from '../assure-selector/_model/assure.model';

export type IdPersonneNOS = string;

export interface NOSBean {
  test?: any;
  dateEffetPresumee: string;
  departementTarification: string;
  resiliationCompagnie: string;
  resiliationAutre: string;
  codeCompagnieResiliation?: any;
  isAssureSouscripteur: string;
  assureBeanList: Assures;
  nonAssureBeanList: Assures;
  souscripteurBean: SouscripteurBean;
  resultatsOffreBean: ResultatsOffreBean;
  finalisationOffreBean: FinalisationOffreBean;
  propositionBean: PropositionBean;
  visaBean: VisaBean;
  gammeBeanSelect: GammeBean;
  familleProduit?: any;
  topOuverturePanel1: boolean;
  cotisationMadelinElligible?: any;
  cotisationMadelinNonElligible?: any;
  dateCreationAncienDevis?: any;
  mapAttributRO: MapAttributRO2;
  indexAssurePrincipal: number;
  nbAssure: number;
  nbNonAssure: number;
  assureBeanPrincipal: Assure;
}

export interface MapAttributRO2 {}

export interface VisaBean {
  statut: string;
  description?: any;
}

export interface PropositionBean {
  acompte: number;
  quittanceConfiee?: any;
  crg: string;
  ribPrelevement?: any;
  ribPrestation?: any;
  abrogationBeanList?: any;
  dateClotureBilan?: any;
  topTelegestion: string;
  refProposition?: any;
}

export interface FinalisationOffreBean {
  intitule?: any;
  pointDeVente: string;
  chargeClientele: string;
  optionLettreAccompagnement: string;
  optionEtudePerso: string;
  optionBaremesPresta: string;
  autresBesoins?: any;
  garantiesConseillees?: any;
  besoinsExprimes?: any;
  finalisationCourtageOffreBean: FinalisationCourtageOffreBean;
}

export interface FinalisationCourtageOffreBean {
  villeNaissance?: any;
  departementNaissance?: any;
  situationFamille?: any;
  telPrive?: any;
  telPro?: any;
  telFax?: any;
  emailClient?: any;
}

export interface ResultatsOffreBean {
  prelevementBean: PrelevementBean;
  optionAideAcquisition: string;
  optionAdhesionADPS: string;
  topOptionAdhesionADPSControle: boolean;
  optionSansDroitAdhesion: string;
  optionMadelin?: any;
  cotisationTotaleFractionnee: number;
  cotisationAdps: number;
  cotisationTotaleAnnuelle: number;
  libelleReduction?: any;
  tarifRenforts?: any;
  tarifBudget: number;
  reductionFamille: number;
  libelleReductionFamille?: any;
  statistiquesOffreBean: StatistiquesOffreBean;
  aideAcquisitionNonDispo: boolean;
  topBudgetForce?: any;
  topCompteBudget?: any;
  codeBudgetNonDisponible?: any;
}

export interface StatistiquesOffreBean {
  budgetCommercialSoinBeanList: any[];
  operationCommercialeBeanList: OperationCommercialeBeanList[];
  opCom: OperationCommercialeBeanList;
  opSelectionnee?: any;
  opSelectionneeAvant?: any;
  budgetTotalConsomme: number;
  consommeBGA: number;
  disponibleBGA: number;
}

export interface OperationCommercialeBeanList {
  libelleOperationCommerciale?: any;
  codeOperationCommerciale?: any;
  messageInfo?: any;
  topReccur?: any;
}

export interface PrelevementBean {
  prelevementAuto?: any;
  codeFractionnement: string;
  dateprelevement?: any;
}

export interface SouscripteurBean {
  idPersonneNOS: IdPersonneNOS;
  idPr?: any;
  idRattachementPersonneNOS?: any;
  categorieSociale: string;
  categorieSocialeMenu: string;
  categorieSocialeSousMenu?: any;
  dateDebutActivite: string;
  isEnActivite: string;
  dateNaissance: string;
  age: string;
  nom: string;
  prenom: string;
  qualite: string;
  sexe?: any;
  profil?: any;
  libelleProfil?: any;
  rattachementOuCSP: string;
  codePostal: string;
  commune: string;
  complementNumeroRue: string;
  numeroRue: string;
  typeVoie: string;
  voie: string;
  numeroSS: string;
  regimeObligatoire?: any;
  codeProfessionLagon: string;
  mapAttributRO: MapAttributRO;
  isPersonneMorale: boolean;
  nomPersonneMorale?: any;
  personneMorale: boolean;
  prenomNom: string;
  sexeSouscription: string;
  dateNaissancePourMN: string;
  dateDebutActiviteMN: string;
  categorieSocialeTarif: string;
  regimeObligatoireIms: string;
  categorieSocialeIms: string;
}

export interface GammeBean {
  idGamme: string;
  libelleGamme: string;
}

export interface MapAttributRO {
  commune: string;
  voie: string;
  numeroRue: string;
  dateNaissance: string;
  codePostal: string;
  prenom: string;
  qualite: string;
  nom: string;
  numeroSS: string;
  typeVoie: string;
}
