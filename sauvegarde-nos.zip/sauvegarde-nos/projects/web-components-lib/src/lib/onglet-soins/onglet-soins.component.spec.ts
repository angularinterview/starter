import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OngletSoinsComponent } from './onglet-soins.component';

describe('OngletSoinsComponent', () => {
  let component: OngletSoinsComponent;
  let fixture: ComponentFixture<OngletSoinsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [OngletSoinsComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OngletSoinsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
