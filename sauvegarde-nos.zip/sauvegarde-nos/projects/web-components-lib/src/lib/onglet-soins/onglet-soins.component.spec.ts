import { ComponentFixture, TestBed } from '@angular/core/testing';
import { OngletSoinsComponent } from './onglet-soins.component';
import { ENVIRONMENT, OngletSoinsModule } from 'web-components-lib';
import { HttpClientTestingModule } from '@angular/common/http/testing';

describe('OngletSoinsComponent', () => {
  let component: OngletSoinsComponent;
  let fixture: ComponentFixture<OngletSoinsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OngletSoinsModule, HttpClientTestingModule],
      providers: [
        {
          provide: ENVIRONMENT,
          useValue: { production: false, apiBaseUrl: 'api' },
        },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OngletSoinsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
