import { Inject, Injectable } from '@angular/core';
import { IdPersonneNOS, NOSBean } from '../_model/soins.model';
import { Observable } from 'rxjs';
import { Assure, Assures } from '../assure-selector/_model/assure.model';
import { HttpClient } from '@angular/common/http';
import { ENVIRONMENT, Environment } from '../../core/environment/environment.model';
import * as URI from 'urijs';

@Injectable()
export class SoinsService {
  constructor(private http: HttpClient, @Inject(ENVIRONMENT) private env: Environment) {}

  getNosBean(): Observable<NOSBean> {
    return this.http.get<NOSBean>(`${this.env.apiBaseUrl}/nosbean`);
  }

  calculerTarif(nosBean: NOSBean, idPersonneNOS: IdPersonneNOS): Observable<Assures> {
    return this.http.post<Assures>(
      URI(this.env.apiBaseUrl).segment('assures').segment(idPersonneNOS).segment('calculer-tarif').toString(),
      nosBean
    );
  }

  appliquerATous(nosBean: NOSBean, idPersonneNOS: IdPersonneNOS): Observable<Assures> {
    return this.http.post<Assures>(
      URI(this.env.apiBaseUrl).segment('assures').segment(idPersonneNOS).segment('appliquer-a-tous').toString(),
      nosBean
    );
  }

  initCouverture(nosBean: NOSBean, idPersonneNOS: IdPersonneNOS): Observable<Assure> {
    return this.http.post<Assure>(
      URI(this.env.apiBaseUrl).segment('assures').segment(idPersonneNOS).segment('init-couverture').toString(),
      nosBean
    );
  }

  alimenterFormOngletSoins(nosBean: NOSBean): Observable<void> {
    return this.http.post<void>(
      URI(this.env.apiBaseUrl).segment('nosbean').segment('alimenter-form-onglet-soins').toString(),
      nosBean
    );
  }

  alimenterCodesProduit(nosBean: NOSBean): Observable<Assures> {
    return this.http.post<Assures>(
      URI(this.env.apiBaseUrl).segment('nosbean').segment('alimenter-codes-produit').toString(),
      nosBean
    );
  }
}
