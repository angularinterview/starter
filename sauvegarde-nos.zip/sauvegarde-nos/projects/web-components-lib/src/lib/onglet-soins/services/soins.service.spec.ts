import { TestBed } from '@angular/core/testing';

import { SoinsService } from './soins.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ENVIRONMENT } from 'web-components-lib';

describe('SoinsService', () => {
  let service: SoinsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: ENVIRONMENT,
          useValue: { production: false, apiBaseUrl: 'api' },
        },
        SoinsService,
      ],
    });
    service = TestBed.inject(SoinsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
