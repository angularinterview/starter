import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OngletSoinsComponent } from './onglet-soins.component';
import { AssureSelectorModule } from './assure-selector/assure-selector.module';
import { GarantiesSanteModule } from './garanties-sante/garanties-sante.module';
import { ReactiveFormsModule } from '@angular/forms';
import { SoinsService } from './services/soins.service';
import { NgrxStoreModule } from '../core/store/ngrx-store.module';

@NgModule({
  declarations: [OngletSoinsComponent],
  exports: [OngletSoinsComponent],
  imports: [CommonModule, ReactiveFormsModule, AssureSelectorModule, GarantiesSanteModule, NgrxStoreModule],
  providers: [SoinsService],
})
export class OngletSoinsModule {}
