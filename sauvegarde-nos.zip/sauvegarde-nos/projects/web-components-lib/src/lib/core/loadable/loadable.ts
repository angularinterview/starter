import { immerable } from 'immer';

export class Loadable<T> {
  [immerable] = true;

  private constructor(
    public data: T,
    public loading: boolean,
    public error: boolean,
    public errorMessages?: string[]
  ) {}

  static initialState<T>(data: T): Loadable<T> {
    return this.success(data);
  }

  static loading<T>(initialState: Loadable<T>): Loadable<T> {
    return { ...initialState, loading: true };
  }

  static error<T>(error: Error, data: T = {} as T): Loadable<T> {
    return new Loadable(data, false, true, (error?.message || '').split(','));
  }

  static success<T>(data: T): Loadable<T> {
    return new Loadable(data, false, false);
  }
}
