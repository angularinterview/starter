import { AbstractControl, ControlValueAccessor, ValidationErrors, Validator } from '@angular/forms';
import { startWith } from 'rxjs/operators';
import { AfterViewInit, Component } from '@angular/core';

@Component({ template: '' })
// tslint:disable-next-line:component-class-suffix
export abstract class BaseControlValueAccessor implements ControlValueAccessor, Validator, AfterViewInit {
  public onTouched: () => void = () => 1;
  public onChange: (val: any) => void = () => 1;

  abstract getForm(): AbstractControl;

  ngAfterViewInit(): void {
    this.getForm().valueChanges.pipe(startWith(this.getForm().value)).subscribe(this.onChange);
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  registerOnValidatorChange(fn: () => void): void {}

  setDisabledState(isDisabled: boolean): void {
    if (isDisabled) {
      this.getForm().disable();
    } else {
      this.getForm().enable();
    }
  }

  validate(control: AbstractControl): ValidationErrors | null {
    return this.getForm().valid
      ? null
      : {
          invalidForm: {
            valid: false,
            message: 'Form Invalid',
          },
        };
  }

  writeValue(val: any): void {
    if (Boolean(val)) {
      this.getForm().patchValue(val, { emitEvent: false });
    }
  }
}
