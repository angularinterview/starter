import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Notification, NotificationContext } from '../store/notifications/notifications.actions';

export interface DialogButton {
  label: string;
  classes: string[];
  action: () => void;
}

export interface DialogConfig extends Notification {
  header: string;
  buttons: DialogButton[];
}

@Component({
  template: `
    <div class="modal-header bg-light" [ngClass]="CONTEXT_CLASSES_MAP.get(config.context)!">
      <h4 class="modal-title">{{ config.header | uppercase }}</h4>
    </div>
    <div class="modal-body bg-light font-weight-bold">
      <p>{{ config.message }}</p>
    </div>
    <div class="modal-footer bg-light py-1">
      <button
        *ngFor="let button of config.buttons"
        type="button"
        [ngClass]="button.classes"
        class="btn px-3 ml-2 font-weight-bold"
        (click)="button.action()"
      >
        {{ button.label }}
      </button>
    </div>
  `,
})
export class ModalContentComponent {
  readonly DEFAULT_CONFIG: DialogConfig = {
    header: 'Garanties soins',
    context: NotificationContext.INFO,
    message: '',
    buttons: [
      {
        label: 'Close',
        classes: ['btn-outline-dark'],
        action: () => {
          this.activeModal.close(false);
        },
      },
    ],
  };

  readonly CONTEXT_CLASSES_MAP: Map<NotificationContext, string[]> = new Map([
    [NotificationContext.INFO, ['text-primary']],
    [NotificationContext.ERROR, ['text-danger']],
    [NotificationContext.SUCCESS, ['text-success']],
  ]);

  private _config: DialogConfig;

  @Input() set config(config: DialogConfig) {
    this._config = {
      ...this.DEFAULT_CONFIG,
      ...config,
    };
  }

  get config(): DialogConfig {
    return this._config;
  }

  constructor(public activeModal: NgbActiveModal) {}
}
