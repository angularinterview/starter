import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModalContentComponent } from './modal-content.component';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [ModalContentComponent],
  imports: [CommonModule, NgbModalModule],
  exports: [ModalContentComponent],
  entryComponents: [ModalContentComponent],
})
export class ModalContentModule {}
