export abstract class Converter<S, T> {
  abstract convert(source: S): T;
}
