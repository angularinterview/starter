import * as AssuresActions from './assures.actions';

export { AssuresActions };
