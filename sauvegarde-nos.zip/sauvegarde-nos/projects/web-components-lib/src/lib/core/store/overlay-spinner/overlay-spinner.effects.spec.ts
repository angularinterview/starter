import { TestBed } from '@angular/core/testing';
import { Observable, of } from 'rxjs';
import { ActionCreator, ActionType } from '@ngrx/store/src/models';
import { NgxSpinnerService } from 'ngx-spinner';
import { provideMockActions } from '@ngrx/effects/testing';
import { OverlaySpinnerEffects } from './overlay-spinner.effects';
import { OverlaySpinnerActions } from './index';

describe('OverlaySpinnerEffects', () => {
  let actions$: Observable<ActionType<ActionCreator>>;
  let ngxSpinnerService: NgxSpinnerService;
  let overlaySpinnerEffects: OverlaySpinnerEffects;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [OverlaySpinnerEffects, provideMockActions(() => actions$)],
    }).compileComponents();

    ngxSpinnerService = TestBed.inject(NgxSpinnerService);
    overlaySpinnerEffects = TestBed.inject(OverlaySpinnerEffects);
  });

  describe('show$', () => {
    it('should open the overlay spinner', () => {
      const spy = spyOn(ngxSpinnerService, 'show');
      actions$ = of(OverlaySpinnerActions.show());
      overlaySpinnerEffects.show$.subscribe((action) => {
        expect(action).toEqual(OverlaySpinnerActions.show());
        expect(spy).toHaveBeenCalledTimes(1);
      });
    });
  });

  describe('hide$', () => {
    it('should hide the overlay spinner', () => {
      const spy = spyOn(ngxSpinnerService, 'hide');
      actions$ = of(OverlaySpinnerActions.hide());
      overlaySpinnerEffects.hide$.subscribe((action) => {
        expect(action).toEqual(OverlaySpinnerActions.hide());
        expect(spy).toHaveBeenCalledTimes(1);
      });
    });
  });
});
