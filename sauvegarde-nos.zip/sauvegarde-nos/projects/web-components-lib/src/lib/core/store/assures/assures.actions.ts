import { createAction, props } from '@ngrx/store';
import { Assure, Assures } from '../../../onglet-soins/assure-selector/_model/assure.model';
import { IdPersonneNOS } from '../../../onglet-soins/_model/soins.model';
import { GarantiesSante } from '../../../onglet-soins/garanties-sante/_model/garanties-sante.model';

export const assuresLoaded = createAction('[Assures] assures Loaded', props<{ assures: Assures }>());

export const calculerTarif = createAction('[Assures] calculer tarif', props<{ idPersonneNOS: IdPersonneNOS }>());

export const updateAssures = createAction('[Assures] update assure', props<{ assures: Assures }>());

export const garantiesSanteChanged = createAction(
  '[Assures] garanties sante changed',
  props<{ garantiesSante: GarantiesSante; idPersonneNOS: IdPersonneNOS }>()
);

export const appliquerATous = createAction('[Assures] appliquer à tous', props<{ idPersonneNOS: IdPersonneNOS }>());

export const initCouverture = createAction('[Assures] init couverture', props<{ idPersonneNOS: IdPersonneNOS }>());
