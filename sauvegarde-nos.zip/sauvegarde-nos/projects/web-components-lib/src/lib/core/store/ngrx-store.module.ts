import { NgModule } from '@angular/core';
import { ActionReducer, META_REDUCERS, StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { OverlaySpinnerEffects } from './overlay-spinner/overlay-spinner.effects';
import { NgxSpinnerModule } from 'ngx-spinner';
import { ENVIRONMENT, Environment } from '../environment/environment.model';
import { assuresReducer, AssuresState } from './assures/assures.reducer';
import { nosBeanReducer, NosBeanState } from './nos-bean/nos-bean.reducer';
import { NosBeanEffects } from './nos-bean/nos-bean.effects';
import { NosBeanFacade } from './nos-bean/nos-bean.facade';
import { NotificationsEffects } from './notifications/notifications.effects';
import { AssuresFacade } from './assures/assures.facade';
import { AssuresEffects } from './assures/assures.effects';

export interface AppState {
  assures: AssuresState;
  nosbean: NosBeanState;
}

export const debugMetaReducerFactory = (env: Environment) => (reducer: ActionReducer<any>): ActionReducer<any> => {
  return (state, action) => {
    const { type, ...payload } = action;
    const nextState = reducer(state, action);
    if (!env.production) {
      console.log('%cAction :', 'font-weight: bold', type);
      console.log('%c payload ', 'color: blue; font-weight: bold', payload);
      console.log('%c prev state', 'color: #9E9E9E; font-weight: bold', state);
      console.log('%c next state', 'color: #4CAF50; font-weight: bold', nextState);
    }
    return nextState;
  };
};

@NgModule({
  imports: [
    NgxSpinnerModule,
    StoreModule.forRoot<AppState>({
      assures: assuresReducer,
      nosbean: nosBeanReducer,
    }),
    EffectsModule.forRoot([OverlaySpinnerEffects, NotificationsEffects, NosBeanEffects, AssuresEffects]),
  ],
  exports: [NgxSpinnerModule],
  providers: [
    NosBeanFacade,
    AssuresFacade,
    {
      provide: META_REDUCERS,
      useFactory: debugMetaReducerFactory,
      deps: [ENVIRONMENT],
      multi: true,
    },
  ],
})
export class NgrxStoreModule {}
