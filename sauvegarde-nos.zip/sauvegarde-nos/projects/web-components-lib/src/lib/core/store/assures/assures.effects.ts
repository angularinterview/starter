import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, startWith, switchMap, withLatestFrom } from 'rxjs/operators';
import { AssuresActions } from './index';
import { SoinsService } from '../../../onglet-soins/services/soins.service';
import { AppState } from '../ngrx-store.module';
import { select, Store } from '@ngrx/store';
import { ActionType } from '@ngrx/store/src/models';
import { NosBeanState } from '../nos-bean/nos-bean.reducer';
import { NotificationsActions } from '../notifications';
import { OverlaySpinnerActions } from '../overlay-spinner';
import { Assures } from '../../../onglet-soins/assure-selector/_model/assure.model';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable()
export class AssuresEffects {
  calculerTarif$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AssuresActions.calculerTarif),
      withLatestFrom(this.store.pipe(select((state) => Array.from(state.assures.values())))),
      // @ts-ignore
      withLatestFrom(this.store.pipe(select((state) => state.nosbean)), ([action, assures], nosbean) => [
        action,
        assures,
        nosbean,
      ]),
      switchMap(
        ([action, assures, nosbean]: [ActionType<typeof AssuresActions.calculerTarif>, Assures, NosBeanState]) =>
          this.soinsService.calculerTarif({ ...nosbean.data, assureBeanList: assures }, action.idPersonneNOS).pipe(
            switchMap((assures) => [AssuresActions.updateAssures({ assures }), OverlaySpinnerActions.hide()]),
            startWith(OverlaySpinnerActions.show()),
            catchError(({ error }: HttpErrorResponse) => [
              OverlaySpinnerActions.hide(),
              NotificationsActions.open({
                context: 'error',
                message: error.message,
              }),
            ])
          )
      )
    )
  );

  appliquerATous$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AssuresActions.appliquerATous),
      withLatestFrom(this.store.pipe(select((state) => Array.from(state.assures.values())))),
      // @ts-ignore
      withLatestFrom(this.store.pipe(select((state) => state.nosbean)), ([action, assures], nosbean) => [
        action,
        assures,
        nosbean,
      ]),
      switchMap(
        ([action, assures, nosbean]: [ActionType<typeof AssuresActions.calculerTarif>, Assures, NosBeanState]) =>
          this.soinsService.appliquerATous({ ...nosbean.data, assureBeanList: assures }, action.idPersonneNOS).pipe(
            switchMap((assures) => [AssuresActions.assuresLoaded({ assures }), OverlaySpinnerActions.hide()]),
            startWith(OverlaySpinnerActions.show()),
            catchError(({ error }: HttpErrorResponse) => [
              OverlaySpinnerActions.hide(),
              NotificationsActions.open({
                context: 'error',
                message: error.message,
              }),
            ])
          )
      )
    )
  );

  constructor(private actions$: Actions, private store: Store<AppState>, private soinsService: SoinsService) {}
}
