import { NOSBean } from '../../../onglet-soins/_model/soins.model';
import { createReducer, on } from '@ngrx/store';
import { NosBeanActions } from './index';
import { Loadable } from '../../loadable/loadable';
import { AssuresActions } from '../assures';
import { NIVEAU_SOINS_GAMME_BEAN_MAP } from '../../../onglet-soins/assure-selector/_model/assure.constants';
import produce from 'immer';

export type NosBeanWithoutAssures = Omit<NOSBean, 'assureBeanList'>;

export type NosBeanState = Loadable<NosBeanWithoutAssures>;

export const nosBeanInitialState: NosBeanState = Loadable.initialState({} as NosBeanWithoutAssures);

export const nosBeanReducer = createReducer(
  nosBeanInitialState,
  on(NosBeanActions.loadNosBeanStarted, () => Loadable.loading(nosBeanInitialState)),
  on(NosBeanActions.loadNosBeanSuccess, (state, { nosBean }) => {
    const { assureBeanList, ...toRetain } = nosBean;
    return Loadable.success(toRetain);
  }),
  on(NosBeanActions.loadNosBeanError, (state, { error }) => Loadable.error<NosBeanWithoutAssures>(error)),
  on(AssuresActions.garantiesSanteChanged, (state, { garantiesSante }) =>
    produce(state, (draft) => {
      draft.data.gammeBeanSelect = NIVEAU_SOINS_GAMME_BEAN_MAP.get(garantiesSante.niveau)!;
    })
  )
);
