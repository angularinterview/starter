import { createAction } from '@ngrx/store';

export const show = createAction('[Overlay Spinner] Show');

export const hide = createAction('[Overlay Spinner] Hide');
