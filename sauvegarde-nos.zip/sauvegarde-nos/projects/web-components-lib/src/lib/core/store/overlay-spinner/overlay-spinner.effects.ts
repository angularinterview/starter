import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { tap } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';
import { OverlaySpinnerActions } from './index';

@Injectable()
export class OverlaySpinnerEffects {
  constructor(private actions$: Actions, private ngxSpinnerService: NgxSpinnerService) {}

  show$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(OverlaySpinnerActions.show),
        tap(() => this.ngxSpinnerService.show())
      ),
    { dispatch: false }
  );

  hide$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(OverlaySpinnerActions.hide),
        tap(() => this.ngxSpinnerService.hide())
      ),
    { dispatch: false }
  );
}
