import { Assure } from '../../../onglet-soins/assure-selector/_model/assure.model';
import { IdPersonneNOS } from '../../../onglet-soins/_model/soins.model';
import { createReducer, on } from '@ngrx/store';
import { AssuresActions } from './index';
import { GarantiesSanteToSoinAssureConveter } from '../../../onglet-soins/converters/garanties-sante-to-soin-assure.conveter';

export type AssuresState = Map<IdPersonneNOS, Assure>;

export const assuresInitialState: AssuresState = new Map<IdPersonneNOS, Assure>();

export const assuresReducer = createReducer(
  assuresInitialState,
  on(AssuresActions.assuresLoaded, (state, action) =>
    action.assures.reduce(
      (accumulator, assure) => accumulator.set(assure.idPersonneNOS, assure),
      new Map<IdPersonneNOS, Assure>()
    )
  ),
  on(AssuresActions.updateAssure, (state, action) => new Map([...state, [action.assure.idPersonneNOS, action.assure]])),
  on(AssuresActions.garantiesSanteChanged, (state, action) => {
    const assure = state.get(action.idPersonneNOS)!;
    const assureChanged: Assure = {
      ...assure,
      soinAssureBean: {
        ...assure.soinAssureBean,
        ...new GarantiesSanteToSoinAssureConveter().convert(action.garantiesSante),
        tarifChoixClient: 0,
      },
    };
    return new Map([...state, [action.idPersonneNOS, assureChanged]]);
  })
);
