import { Assure } from '../../../onglet-soins/assure-selector/_model/assure.model';
import { IdPersonneNOS } from '../../../onglet-soins/_model/soins.model';
import { createReducer, on } from '@ngrx/store';
import { AssuresActions } from './index';
import { GarantiesSanteToSoinAssureConveter } from '../../../onglet-soins/converters/garanties-sante-to-soin-assure.conveter';

export type AssuresState = Map<IdPersonneNOS, Assure>;

export const assuresInitialState: AssuresState = new Map<IdPersonneNOS, Assure>();

export const assuresReducer = createReducer(
  assuresInitialState,
  on(AssuresActions.assuresLoaded, (state, { assures }) =>
    assures.reduce(
      (accumulator, assure) => accumulator.set(assure.idPersonneNOS, assure),
      new Map<IdPersonneNOS, Assure>()
    )
  ),
  on(
    AssuresActions.updateAssures,
    (state, { assures }) =>
      new Map([...state, ...assures.map<[IdPersonneNOS, Assure]>((assure) => [assure.idPersonneNOS, assure])])
  ),
  on(AssuresActions.garantiesSanteChanged, (state, { idPersonneNOS, garantiesSante }) => {
    const assure = state.get(idPersonneNOS)!;
    const assureChanged: Assure = {
      ...assure,
      soinAssureBean: {
        ...assure.soinAssureBean,
        ...new GarantiesSanteToSoinAssureConveter().convert(garantiesSante),
        tarifChoixClient: 0,
      },
    };
    return new Map([...state, [idPersonneNOS, assureChanged]]);
  })
);
