import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { NosBeanActions } from './index';
import { SoinsService } from '../../../onglet-soins/services/soins.service';
import { catchError, startWith, switchMap, tap, withLatestFrom } from 'rxjs/operators';
import { AssuresActions } from '../assures';
import { OverlaySpinnerActions } from '../overlay-spinner';
import { NotificationsActions } from '../notifications';
import { HttpErrorResponse } from '@angular/common/http';
import { select, Store } from '@ngrx/store';
import { AppState } from '../ngrx-store.module';
import { ActionType } from '@ngrx/store/src/models';
import { Assures } from '../../../onglet-soins/assure-selector/_model/assure.model';
import { NosBeanState } from './nos-bean.reducer';
import { defer, of } from 'rxjs';

@Injectable()
export class NosBeanEffects {
  loadNosBean$ = createEffect(() =>
    this.actions$.pipe(
      ofType(NosBeanActions.loadNosBean),
      switchMap((action) =>
        this.soinsService.getNosBean().pipe(
          switchMap((nosBean) => [
            NosBeanActions.loadNosBeanSuccess({ nosBean }),
            AssuresActions.assuresLoaded({ assures: nosBean.assureBeanList }),
            OverlaySpinnerActions.hide(),
          ]),
          startWith(OverlaySpinnerActions.show(), NosBeanActions.loadNosBeanStarted()),
          catchError(({ error }: HttpErrorResponse) => [
            NosBeanActions.loadNosBeanError({ error }),
            OverlaySpinnerActions.hide(),
            NotificationsActions.open({
              context: 'error',
              message: error.message,
            }),
          ])
        )
      )
    )
  );

  alimenterCodesProduit$ = createEffect(() =>
    this.actions$.pipe(
      ofType(NosBeanActions.alimenterCodesProduit),
      withLatestFrom(this.store.pipe(select((state) => Array.from(state.assures.values())))),
      // @ts-ignore
      withLatestFrom(this.store.pipe(select((state) => state.nosbean)), ([action, assures], nosbean) => [
        action,
        assures,
        nosbean,
      ]),
      switchMap(
        ([{ callback }, assures, nosbean]: [
          ActionType<typeof NosBeanActions.alimenterCodesProduit>,
          Assures,
          NosBeanState
        ]) =>
          defer(() =>
            assures.every((assure) => assure.soinAssureBean.tarifChoixClient > 0)
              ? this.soinsService.alimenterCodesProduit({ ...nosbean.data, assureBeanList: assures }).pipe(
                  switchMap((assures) => [
                    AssuresActions.assuresLoaded({ assures }),
                    OverlaySpinnerActions.hide(),
                    NosBeanActions.alimenterFormOngletSoins({ callback }),
                  ]),
                  startWith(OverlaySpinnerActions.show()),
                  catchError(({ error }: HttpErrorResponse) => [
                    OverlaySpinnerActions.hide(),
                    NotificationsActions.open({
                      context: 'error',
                      message: error.message,
                    }),
                  ])
                )
              : of(
                  NotificationsActions.open({
                    context: 'error',
                    message: "Veuillez lancer la tarification avant de passer à l'onglet suivant.",
                  })
                )
          )
      )
    )
  );

  alimenterFormOngletSoins$ = createEffect(() =>
    this.actions$.pipe(
      ofType(NosBeanActions.alimenterFormOngletSoins),
      withLatestFrom(this.store.pipe(select((state) => Array.from(state.assures.values())))),
      // @ts-ignore
      withLatestFrom(this.store.pipe(select((state) => state.nosbean)), ([action, assures], nosbean) => [
        action,
        assures,
        nosbean,
      ]),
      switchMap(
        ([action, assures, nosbean]: [
          ActionType<typeof NosBeanActions.alimenterFormOngletSoins>,
          Assures,
          NosBeanState
        ]) =>
          this.soinsService.alimenterFormOngletSoins({ ...nosbean.data, assureBeanList: assures }).pipe(
            tap(() => action.callback()),
            switchMap(() => [OverlaySpinnerActions.hide()]),
            startWith(OverlaySpinnerActions.show()),
            catchError(({ error }: HttpErrorResponse) => [
              OverlaySpinnerActions.hide(),
              NotificationsActions.open({
                context: 'error',
                message: error.message,
              }),
            ])
          )
      )
    )
  );

  constructor(private actions$: Actions, private store: Store<AppState>, private soinsService: SoinsService) {}
}
