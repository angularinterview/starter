import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { NosBeanActions } from './index';
import { SoinsService } from '../../../onglet-soins/services/soins.service';
import { catchError, startWith, switchMap } from 'rxjs/operators';
import { AssuresActions } from '../assures';
import { OverlaySpinnerActions } from '../overlay-spinner';
import { NotificationsActions } from '../notifications';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable()
export class NosBeanEffects {
  loadNosBean$ = createEffect(() =>
    this.actions$.pipe(
      ofType(NosBeanActions.loadNosBean),
      switchMap((action) =>
        this.soinsService.getNosBean().pipe(
          switchMap((nosBean) => [
            NosBeanActions.loadNosBeanSuccess({ nosBean }),
            AssuresActions.assuresLoaded({ assures: nosBean.assureBeanList }),
            OverlaySpinnerActions.hide(),
          ]),
          startWith(OverlaySpinnerActions.show(), NosBeanActions.loadNosBeanStarted()),
          catchError(({ error }: HttpErrorResponse) => [
            NosBeanActions.loadNosBeanError({ error }),
            OverlaySpinnerActions.hide(),
            NotificationsActions.open({
              context: 'error',
              message: error.message,
            }),
          ])
        )
      )
    )
  );

  constructor(private actions$: Actions, private soinsService: SoinsService) {}
}
