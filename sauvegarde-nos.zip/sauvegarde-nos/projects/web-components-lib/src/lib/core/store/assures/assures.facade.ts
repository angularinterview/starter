import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { AppState } from '../ngrx-store.module';
import { Observable } from 'rxjs';
import { Assures } from '../../../onglet-soins/assure-selector/_model/assure.model';
import { filter } from 'rxjs/operators';
import { IdPersonneNOS } from '../../../onglet-soins/_model/soins.model';
import { AssuresActions } from './index';
import { GarantiesSante } from '../../../onglet-soins/garanties-sante/_model/garanties-sante.model';

@Injectable()
export class AssuresFacade {
  assures$: Observable<Assures> = this.store.pipe(
    select((state) => Array.from(state.assures.values())),
    filter((assures) => assures.length > 0)
  );

  constructor(private store: Store<AppState>) {}

  updateGarantiesSanteAssure(idPersonneNOS: IdPersonneNOS, garantiesSante: GarantiesSante) {
    this.store.dispatch(AssuresActions.garantiesSanteChanged({ garantiesSante, idPersonneNOS }));
  }

  calculerTarif(idPersonneNOS: IdPersonneNOS) {
    this.store.dispatch(AssuresActions.calculerTarif({ idPersonneNOS }));
  }

  appliquerATous(idPersonneNOS: IdPersonneNOS) {
    this.store.dispatch(AssuresActions.appliquerATous({ idPersonneNOS }));
  }
}
