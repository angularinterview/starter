import { createAction, props } from '@ngrx/store';

// import { BANNER_CONTEXT } from '@aposin/ng-aquila/message';

export interface Notification {
  context: 'error' | 'sucess' | 'info'; // BANNER_CONTEXT;
  message: string;
}

export const open = createAction('[Notifications] Open', props<Notification>());
