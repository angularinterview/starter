import { createAction, props } from '@ngrx/store';

export enum NotificationContext {
  'ERROR',
  'SUCCESS',
  'INFO',
}

export interface Notification {
  context: NotificationContext;
  message: string;
}

export const open = createAction('[Notifications] Open', props<Notification>());
