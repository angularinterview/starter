import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { NosBeanActions } from './index';
import { AppState } from '../ngrx-store.module';

@Injectable()
export class NosBeanFacade {
  constructor(private store: Store<AppState>) {}

  loadNosBean() {
    this.store.dispatch(NosBeanActions.loadNosBean());
  }
}
