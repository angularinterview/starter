import { createAction, props } from '@ngrx/store';
import { NOSBean } from '../../../onglet-soins/_model/soins.model';

export const loadNosBean = createAction('[NosBean] load nosbean');

export const loadNosBeanStarted = createAction('[NosBean] load nosbean started');

export const loadNosBeanSuccess = createAction('[NosBean] load nosbean success', props<{ nosBean: NOSBean }>());

export const loadNosBeanError = createAction('[NosBean] load nosbean error', props<{ error: Error }>());
