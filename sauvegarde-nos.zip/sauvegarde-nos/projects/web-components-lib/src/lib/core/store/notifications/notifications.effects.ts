import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { NotificationsActions } from './index';
import { tap } from 'rxjs/operators';

@Injectable()
export class NotificationsEffects {
  open$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(NotificationsActions.open),
        tap((action) => {
          alert(action.message);
        })
      ),
    { dispatch: false }
  );

  constructor(private actions$: Actions) {}
}
