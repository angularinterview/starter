import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { NotificationsActions } from './index';
import { tap } from 'rxjs/operators';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ModalContentComponent } from '../../modal/modal-content.component';

@Injectable()
export class NotificationsEffects {
  open$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(NotificationsActions.open),
        tap(({ context, message }) => {
          const modalRef = this.modalService.open(ModalContentComponent);
          modalRef.componentInstance.config = { message, context };
        })
      ),
    { dispatch: false }
  );

  constructor(private actions$: Actions, private modalService: NgbModal) {}
}
