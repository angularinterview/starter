/*
 * Public API Surface of web-components-lib
 */

export * from './lib/onglet-soins';

export * from './lib/core/environment/environment.model';
