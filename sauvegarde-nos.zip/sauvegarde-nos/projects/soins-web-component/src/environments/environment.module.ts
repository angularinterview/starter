import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { environment } from './environment';
import { ENVIRONMENT } from 'web-components-lib';

@NgModule({
  imports: [CommonModule],
  providers: [
    {
      provide: ENVIRONMENT,
      useValue: environment,
    },
  ],
})
export class EnvironmentModule {}
