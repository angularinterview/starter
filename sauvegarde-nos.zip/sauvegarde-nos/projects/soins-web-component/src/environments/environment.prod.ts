import { Environment } from 'web-components-lib';

export const environment: Environment = {
  production: true,
  apiBaseUrl: './api',
};
