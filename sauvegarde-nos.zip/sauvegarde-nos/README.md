# control de données flex 

function recupererNomFormulaire(ongletPrec, ongletSuiv){
	if (ongletPrec=='ongletAssure'){
		return 'ongletAssureOavForm';
	} else if (ongletPrec=='ongletSoins'){

		if (ongletSuiv=='ongletAssure'){
		    //si clic sur l'onglet Assur�, alors pas de controle FLEX des donn�es saisies de l'onglet Soins 
			document.getElementById("OngletSoinsSWF").alimentationFormOngletSoinsJS(false);
		} else {
		    //si clic sur un onglet autre que Assur�, alors demander � FLEX le controle des donn�es saisies de l'onglet Soins 
			if (document.getElementById("OngletSoinsSWF")!=null)
			document.getElementById("OngletSoinsSWF").alimentationFormOngletSoinsJS(true);
 		}
	
		//return 'ongletSoinsOavForm';
		return null;
