import * as db from "./db.json";
import { Assures } from "../projects/web-components-lib/src/lib/onglet-soins/assure-selector/_model/assure.model";
import { NOSBean } from "../projects/web-components-lib/src/lib/onglet-soins/_model/soins.model";

// @ts-ignore
export const nosBeanMock: NOSBean = db["nosbean"];


