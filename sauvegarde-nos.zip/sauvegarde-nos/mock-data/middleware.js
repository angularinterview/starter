module.exports = (req, res, next) => {
  if (req.method === "POST" && (
    req.originalUrl.startsWith("/calculer-tarif-") ||
    req.originalUrl.startsWith("/appliquer-a-tous-") ||
    req.originalUrl.startsWith("/init-couverture-"))
  ) {
    req.method = "GET";
  }
  next();
};
