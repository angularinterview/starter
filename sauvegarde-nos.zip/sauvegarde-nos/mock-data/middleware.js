module.exports = (req, res, next) => {
  if (req.method === "POST" && (req.originalUrl.startsWith("/calculer-tarif-") || req.originalUrl === "/appliquer-a-tous")) {
    req.method = "GET";
  }
  next();
};
