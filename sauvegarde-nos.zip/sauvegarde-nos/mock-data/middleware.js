module.exports = (req, res, next) => {
  if (req.method === "POST" && (req.originalUrl.startsWith("/calculer-tarif-") || req.originalUrl.contains('appliquer-a-tous'))) {
    req.method = "GET";
  }
  next();
};
