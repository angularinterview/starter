import { NgModule } from '@angular/core';
import { MainLayoutModule } from './layout/main-layout/main-layout.module';

@NgModule({
  imports: [MainLayoutModule],
  exports: [MainLayoutModule],
})
export class CoreModule {}
