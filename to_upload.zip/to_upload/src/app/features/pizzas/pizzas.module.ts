import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PizzasRoutingModule } from './pizzas-routing.module';
import { PizzasComponent } from './pizzas.component';
import { PizzasListModule } from './pizzas-list/pizzas-list.module';
import { PizzasCreateModule } from './pizzas-create/pizzas-create.module';
import { MatButtonModule } from '@angular/material/button';

@NgModule({
  declarations: [PizzasComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    PizzasRoutingModule,
    PizzasCreateModule,
    PizzasListModule,
  ],
})
export class PizzasModule {}
