import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PizzasCreateComponent } from './pizzas-create.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { NxCheckboxModule } from '@aposin/ng-aquila/checkbox';

@NgModule({
  declarations: [PizzasCreateComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    NxCheckboxModule
  ],
})
export class PizzasCreateModule {}
