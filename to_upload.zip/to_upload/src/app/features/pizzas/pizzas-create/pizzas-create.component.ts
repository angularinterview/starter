import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import {
  AbstractControl,
  FormArray,
  FormBuilder,
  FormGroup,
} from '@angular/forms';
import { PizzasForm, ToppingForm } from '../_models/pizzas-form.model';
import { PizzasSize, PizzaToppingsEnum } from '../_models/pizzas.model';

@Component({
  selector: 'alz-pizzas-create',
  templateUrl: './pizzas-create.component.html',
  styleUrls: ['./pizzas-create.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PizzasCreateComponent implements OnInit {
  readonly createPizzasForm: FormGroup;
  readonly PizzasSize = PizzasSize;
  readonly availableToppings = [...Object.keys(PizzaToppingsEnum)];

  constructor(private fb: FormBuilder) {
    this.createPizzasForm = fb.group(new PizzasForm());
    this.availableToppings.forEach((topping) => {
      (this.createPizzasForm.get('toppings') as FormArray).push(
        fb.group(new ToppingForm(topping))
      );
    });
  }

  get toppings(): AbstractControl[] {
    return (this.createPizzasForm.get('toppings') as FormArray).controls;
  }

  ngOnInit(): void {}

  print(): void {
    console.log(this.createPizzasForm.value);
  }
}
