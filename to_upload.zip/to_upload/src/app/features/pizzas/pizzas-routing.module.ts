import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PizzasComponent } from './pizzas.component';
import { PizzasCreateComponent } from './pizzas-create/pizzas-create.component';

const routes: Routes = [
  {
    path: '',
    component: PizzasComponent,
    children: [
      {
        path: 'create',
        component: PizzasCreateComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PizzasRoutingModule {}
