export enum PizzasSize {
  SMALL = 'SMALL',
  MEDIUM = 'MEDIUM',
  LARGE = 'LARGE',
}

export interface Pizzas {
  size: PizzasSize;
  toppings: PizzaToppingsEnum[];
}

export enum PizzaToppingsEnum {
  SAUSAGE = 'Sausage',
  PEPPERONI = 'Pepperoni',
  HAM = 'Ham',
  OLIVES = 'Olives',
  BACON = 'Bacon',
  CORN = 'Corn',
  PINEAPPLE = 'Pineapple',
  MUSHROOMS = 'Mushrooms',
}
