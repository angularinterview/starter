import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { Pizzas } from './pizzas.model';

export class PizzasForm {
  size = new FormControl(null, Validators.required);
  toppings = new FormArray([]);

  constructor(pizzas?: Pizzas) {
    if (pizzas) {
      this.size.setValue(pizzas.size);
    }
  }
}

export class ToppingForm {
  name = new FormControl(null, Validators.required);
  selected = new FormControl(false, Validators.required);

  constructor(name: string) {
    this.name.setValue(name);
  }
}
