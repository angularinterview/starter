import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'alz-pizzas',
  template: `
    <div class="row h-100">
      <div class="col-3 border">
        <button mat-flat-button color="primary" routerLink="create">
          Create
        </button>
        <alz-pizzas-list></alz-pizzas-list>
      </div>
      <div class="col-9 border">
        <router-outlet></router-outlet>
      </div>
    </div>
  `,
})
export class PizzasComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
