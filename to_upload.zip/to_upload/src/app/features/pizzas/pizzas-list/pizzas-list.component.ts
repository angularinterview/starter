import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'alz-pizzas-list',
  templateUrl: './pizzas-list.component.html',
  styleUrls: ['./pizzas-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PizzasListComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
