import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PizzasListComponent } from './pizzas-list.component';

@NgModule({
  declarations: [PizzasListComponent],
  exports: [PizzasListComponent],
  imports: [CommonModule],
})
export class PizzasListModule {}
