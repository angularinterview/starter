import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  HostListener,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { SortDirection } from '@angular/material/sort';

export interface SortEvent {
  column: string;
  direction: SortDirection;
}

const rotate: { [key: string]: SortDirection } = {
  asc: 'desc',
  desc: '',
  '': 'asc',
};

@Component({
  // tslint:disable-next-line:component-selector directive-selector
  selector: 'th[sortable]',
  template: `
    <span
      class="sort-direction"
      [ngClass]="{ top: direction === 'asc', down: direction === 'desc' }"
    ></span>
    <ng-content></ng-content>
  `,
  styleUrls: ['./sortable.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SortableComponent {
  @Input() sortable = '';
  @Input() direction: SortDirection = '';
  @Output() sort = new EventEmitter<SortEvent>();

  @HostListener('click')
  rotate(): void {
    this.direction = rotate[this.direction];
    this.sort.emit({ column: this.sortable, direction: this.direction });
  }
}
