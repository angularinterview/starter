import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TagListModule } from './tag-list/tag-list.module';

@NgModule({
  declarations: [],
  imports: [CommonModule, TagListModule],
  exports: [TagListModule],
})
export class SharedModule {}
