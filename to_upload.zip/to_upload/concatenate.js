const fs = require('fs-extra');
const concat = require('concat');

(async function build() {
  const files = [
    './dist/soins-web-component/runtime.js',
    './dist/soins-web-component/polyfills-es5.js',
    './dist/soins-web-component/main.js',
  ]
  // await fs.ensureDir('elements')
  await concat(files, './dist/soins-web-component/soins-web-component.js');
  // await fs.copyFile('./dist/angular-elements/styles.css', 'elements/styles.css')
  // await fs.copy('./dist/angular-elements/assets/', 'elements/assets/' )
})()
