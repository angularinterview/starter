/*
 * Public API Surface of web-components-lib
 */

export * from './lib/soins';
