import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  Input,
  OnInit,
  QueryList,
  ViewChildren,
  ViewEncapsulation,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NiveauSoinsEnum } from './_models/soins.enums';
import { NxRadioComponent } from '@aposin/ng-aquila/radio-button';

@Component({
  selector: 'lib-soins',
  templateUrl: './soins.component.html',
  styleUrls: ['soins.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class SoinsComponent implements OnInit, AfterViewInit {
  @ViewChildren(NxRadioComponent) radios!: QueryList<NxRadioComponent>;
  readonly NiveauSoinsEnum = NiveauSoinsEnum;
  readonly soinsForm: FormGroup;

  @Input() autresNiveauxDesactives = false;

  constructor(
    private fb: FormBuilder,
    private changeDetectorRef: ChangeDetectorRef
  ) {
    this.soinsForm = fb.group({
      niveau: [NiveauSoinsEnum.NIVEAU_3, Validators.required],
    });
  }

  ngOnInit(): void {}

  ngAfterViewInit(): void {
    if (this.autresNiveauxDesactives) {
      this.radios.forEach((item) => {
        if (item.value !== this.soinsForm.get('niveau')?.value) {
          item.disabled = true;
        }
      });
      this.changeDetectorRef.detectChanges();
    }
  }
}
