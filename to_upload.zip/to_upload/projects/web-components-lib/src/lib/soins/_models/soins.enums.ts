export enum NiveauSoinsEnum {
  HOSPI = 'HOSPI',
  ECO = 'ECO',
  NIVEAU_1 = 'NIVEAU_1',
  NIVEAU_2 = 'NIVEAU_2',
  NIVEAU_3 = 'NIVEAU_3',
  NIVEAU_4 = 'NIVEAU_4',
  NIVEAU_5 = 'NIVEAU_5',
  NIVEAU_6 = 'NIVEAU_6',
  NIVEAU_7 = 'NIVEAU_7',
}

export enum TypeRenfortEnum {
  SERENITE = 'SERENITE',
  OPTIQUE = 'OPTIQUE',
  DENTAIRE = 'DENTAIRE',
}
