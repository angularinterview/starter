import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SoinsComponent } from './soins.component';
import { NxCheckboxModule } from '@aposin/ng-aquila/checkbox';
import { ReactiveFormsModule } from '@angular/forms';
import { NxRadioModule } from '@aposin/ng-aquila/radio-button';

@NgModule({
  declarations: [SoinsComponent],
  exports: [SoinsComponent],
  imports: [CommonModule, ReactiveFormsModule, NxCheckboxModule, NxRadioModule],
})
export class SoinsModule {}
