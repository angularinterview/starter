export * from './soins.component';
export * from './soins.module';
