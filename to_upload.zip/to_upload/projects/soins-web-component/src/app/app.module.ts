import { BrowserModule } from '@angular/platform-browser';
import { Injector, NgModule } from '@angular/core';
import { SoinsComponent, SoinsModule } from 'web-components-lib';
import { createCustomElement } from '@angular/elements';

@NgModule({
  imports: [BrowserModule, SoinsModule],
})
export class AppModule {
  constructor(private injector: Injector) {}

  ngDoBootstrap(): void {
    const element = createCustomElement(SoinsComponent, {
      injector: this.injector,
    });
    customElements.define('soins-web-component', element);
  }
}
