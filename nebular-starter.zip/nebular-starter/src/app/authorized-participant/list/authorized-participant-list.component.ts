import { Component } from '@angular/core';

@Component({
  selector: 'authorized-participant-list',
  template: `
    <div class="my-3">
      <a [routerLink]="['create']">Create</a>
    </div>
    <ul>
      <li><a [routerLink]="[1]">AP 1</a></li>
      <li><a [routerLink]="[2]">AP 2</a></li>
    </ul>
  `
})
export class AuthorizedParticipantListComponent {

}
