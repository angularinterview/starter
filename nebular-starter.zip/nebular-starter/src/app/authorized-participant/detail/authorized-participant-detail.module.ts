import { NgModule } from '@angular/core';
import { AuthorizedParticipantDetailComponent } from './authorized-participant-detail.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ApDetailUserGroupComponent } from './user-group/ap-detail-user-group.component';
import { AuthorizedParticipantDetailMainComponent } from './main/authorized-participant-detail-main.component';
import { ReactiveFormsModule } from '@angular/forms';
import { AuthorizedParticipantCreateMainModule } from '../create/main/authorized-participant-create-main.module';
import { NbButtonModule } from '@nebular/theme';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    NbButtonModule,
    ReactiveFormsModule,
    AuthorizedParticipantCreateMainModule
  ],
  exports: [
    AuthorizedParticipantDetailComponent,
    AuthorizedParticipantDetailMainComponent,
    ApDetailUserGroupComponent
  ],
  declarations: [
    AuthorizedParticipantDetailComponent,
    AuthorizedParticipantDetailMainComponent,
    ApDetailUserGroupComponent
  ],
  providers: [

  ],
})
export class AuthorizedParticipantDetailModule {
}
