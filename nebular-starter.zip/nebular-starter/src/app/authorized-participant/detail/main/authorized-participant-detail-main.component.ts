import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AuthorizedParticipantMainFormService } from '../../create/main/authorized-participant-main-form.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'authorized-participant-detail-main',
  template: `
    <div [formGroup]="editMainInfoForm">
      <authorized-participant-create-main formControlName="main"></authorized-participant-create-main>

      <button nbButton (click)="save()">Save</button>
      {{'invalid : ' + editMainInfoForm.invalid + ' - dirty : ' + editMainInfoForm.dirty + ' - touched : ' + editMainInfoForm.touched}}
    </div>
  `
})

export class AuthorizedParticipantDetailMainComponent implements OnInit {
  editMainInfoForm: FormGroup;

  constructor(private route: ActivatedRoute,
              private fb: FormBuilder,
              private authorizedParticipantMainFormService: AuthorizedParticipantMainFormService) {
    this.editMainInfoForm = this.fb.group({
      main: this.fb.control('')
    });
  }

  ngOnInit() {
    const apMainInfo = this.route.snapshot.data.main;
    this.authorizedParticipantMainFormService.resetForm();
    this.authorizedParticipantMainFormService.patch(apMainInfo);
  }

  save() {
    console.log('Edit Form', this.editMainInfoForm.value);
  }
}
