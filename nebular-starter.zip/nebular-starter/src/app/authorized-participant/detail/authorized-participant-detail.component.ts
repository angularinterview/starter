import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'authorized-participant-detail',
  template:`
    <a [routerLink]="['/authorized-participants']"><- Back</a>
    <h5>Authorized Participant Detail</h5>
    <ul class="nav nav-tabs">
      <li class="nav-item">
        <a class="nav-link" [routerLink]="['main']" [routerLinkActive]="['active']">Main</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" [routerLink]="['user-group']" [routerLinkActive]="['active']">User group</a>
      </li>            
    </ul>
    <router-outlet></router-outlet>
  `
})

export class AuthorizedParticipantDetailComponent implements OnInit {
  constructor() {
  }

  ngOnInit() {
  }
}
