import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthorizedParticipantMainInfoForm } from './main/_models/authorized-participant-main-info-form.model';

@Component({
  selector: 'authorized-participant-create',
  templateUrl: './authorized-participant-create.component.html'
})

export class AuthorizedParticipantCreateComponent {
  authorizedParticipantForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.authorizedParticipantForm = fb.group({
      mainInformation: new FormControl(),
      settlementInstructions: new FormControl(),
      userGroups: new FormControl()
    });
  }

  ngOnInit() {

  }

  isInvalid(formToCheck: FormGroup) {
    return formToCheck.invalid && (formToCheck.dirty || formToCheck.touched);
  }

  displayForm() {
    console.warn(this.authorizedParticipantForm.value)
  }
}
