import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { AuthorizedParticipantCreateMainComponent } from './authorized-participant-create-main.component';
import { NbInputModule, NbListModule, NbRadioModule } from '@nebular/theme';
import { AuthorizedParticipantMainFormService } from './authorized-participant-main-form.service';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NbInputModule,
    NbRadioModule,
    NbListModule
  ],
  exports: [
    AuthorizedParticipantCreateMainComponent
  ],
  declarations: [
    AuthorizedParticipantCreateMainComponent
  ],
  providers: [AuthorizedParticipantMainFormService],
})
export class AuthorizedParticipantCreateMainModule {
}
