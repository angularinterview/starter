import { AfterViewChecked, AfterViewInit, Component, forwardRef, OnInit } from '@angular/core';
import {
  AbstractControl,
  ControlValueAccessor,
  FormArray,
  FormGroup,
  NG_VALIDATORS,
  NG_VALUE_ACCESSOR,
  ValidationErrors,
  Validator
} from '@angular/forms';
import { AuthorizedParticipantMainFormService } from './authorized-participant-main-form.service';

@Component({
  selector: 'authorized-participant-create-main',
  templateUrl: './authorized-participant-create-main.component.html',
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => AuthorizedParticipantCreateMainComponent),
      multi: true
    },
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => AuthorizedParticipantCreateMainComponent),
      multi: true
    }
  ]
})
export class AuthorizedParticipantCreateMainComponent implements OnInit, AfterViewInit,ControlValueAccessor, Validator {
  mainInformationForm: FormGroup;
  settlementContacts: FormArray;
  types = [
    {value: 'AP', label: 'Authorized Participant'},
    {value: 'ETF', label: 'ETF Owner'},
    {value: 'TA', label: 'TA'}
  ];
  private onChange;
  constructor(public authorizedParticipantMainFormService: AuthorizedParticipantMainFormService) {
  }

  ngOnInit() {
    this.authorizedParticipantMainFormService.mainInformationForm$.subscribe(
      apMainInfoForm => {
        this.mainInformationForm = apMainInfoForm;
        this.settlementContacts = apMainInfoForm.get('settlementContacts') as FormArray;
      }
    );


  }

  ngAfterViewInit(): void {
    // allows the parent formGroup to be notified for the initial Form Value
    setTimeout(() => this.onChange(this.mainInformationForm.value));
  }

  addSettlementContact() {
    this.authorizedParticipantMainFormService.addSettlementContact();
  }

  deleteSetlementContact(index: number) {
    this.authorizedParticipantMainFormService.deleteSettlmentContact(index);
  }

  isInvalid(formToCheck: AbstractControl) {
    return formToCheck.invalid && (formToCheck.dirty || formToCheck.touched);
  }


  private onTouched() {};


  writeValue(val: any): void {
    console.log("writeValue", val);
    // val && this.mainInformationForm.setValue(val, {emitEvent: false});
  }

  registerOnChange(fn: any): void {
    console.log("on change");
    this.onChange = fn;
    this.mainInformationForm.valueChanges.subscribe(fn);
  }

  registerOnTouched(fn: any): void {
    // console.log("on blur");
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    isDisabled ? this.mainInformationForm.disable() : this.mainInformationForm.enable();
  }

  validate(c: AbstractControl): ValidationErrors | null {
    console.log("Basic Info validation", c);
    return this.mainInformationForm.valid ? null : {
      invalidForm: {
        valid: false,
        message: "mainInformationForm fields are invalid"
      }
    };
  }
}
