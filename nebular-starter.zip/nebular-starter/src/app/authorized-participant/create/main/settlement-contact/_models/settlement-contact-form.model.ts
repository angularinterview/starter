import { FormControl, Validators } from '@angular/forms';
import { SettlementContact } from './settlement-contact.model';

export class SettlementContactForm {
  name = new FormControl('', Validators.required);
  email = new FormControl();
  phone = new FormControl();

  constructor(settlementContact?: SettlementContact) {
    if(settlementContact) {
      this.name.setValue(settlementContact.name);
      this.email.setValue(settlementContact.email);
      this.phone.setValue(settlementContact.phone);
    }
  }
}
