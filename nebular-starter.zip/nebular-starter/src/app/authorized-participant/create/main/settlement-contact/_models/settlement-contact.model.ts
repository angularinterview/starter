export class SettlementContact {
  name: string;
  email: string;
  phone: string;
}
