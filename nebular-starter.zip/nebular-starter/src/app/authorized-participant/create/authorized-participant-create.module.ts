import { NgModule } from '@angular/core';
import { AuthorizedParticipantCreateComponent } from './authorized-participant-create.component';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NbButtonModule, NbCardModule, NbInputModule, NbStepperModule } from '@nebular/theme';
import { ReactiveFormsModule } from '@angular/forms';
import { AuthorizedParticipantCreateMainModule } from './main/authorized-participant-create-main.module';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NbCardModule,
    NbButtonModule,
    NbInputModule,
    RouterModule,
    NbStepperModule,
    AuthorizedParticipantCreateMainModule
  ],
  exports: [
    AuthorizedParticipantCreateComponent
  ],
  declarations: [
    AuthorizedParticipantCreateComponent
  ],
  providers: [],
})
export class AuthorizedParticipantCreateModule {
}
