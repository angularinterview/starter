import { AuthorizedParticipantMainInfo } from '../create/main/_models/authorized-participant-main-info.model';

export class AuthorizedParticipant {
  mainInformation: AuthorizedParticipantMainInfo;
  userGroups: Array<string>;
}
